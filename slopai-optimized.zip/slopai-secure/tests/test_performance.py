"""Regression checks for bounded history and one-time migration correctness."""
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from app import create_app

class PerformanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.tmp.name)/'test.sqlite3')
        self.config={'TESTING':True,'SECRET_KEY':'test-only','DATABASE':self.path}
        self.app=create_app(self.config)
        self.client=self.app.test_client()
        with sqlite3.connect(self.path) as c:
            c.executemany('INSERT INTO users(id,name,email,password_hash) VALUES(?,?,?,?)',[(1,'One','one@example.invalid','disabled'),(2,'Two','two@example.invalid','disabled')])
            c.execute('INSERT INTO auth_sessions VALUES(?,1,?)',(hashlib.sha256(b'test-sid').hexdigest(),time.time()+3600))
            c.executemany("INSERT INTO orders(id,user_id,items,total,phone,address,token) VALUES(?,?,'[]',100,'test','test',?)",[(i,1 if i%2 else 2,f'token-{i}') for i in range(1,104)])
        with self.client.session_transaction() as s:s['sid']='test-sid'
    def tearDown(self): self.tmp.cleanup()
    def test_pages_no_duplicates_no_other_users_and_deleted_cursor(self):
        import re
        all_ids=[];url='/account'
        while url:
            response=self.client.get(url)
            self.assertEqual(response.status_code,200)
            html=response.get_data(as_text=True)
            ids=[int(x) for x in re.findall(r'Заказ #(\d+)',html)]
            self.assertLessEqual(len(ids),20);all_ids.extend(ids)
            cursor=re.search(r'href="(/account\?before=\d+)"',html)
            url=cursor.group(1) if cursor else None
        self.assertEqual(all_ids,list(range(103,0,-2)))
        with sqlite3.connect(self.path) as c:c.execute('DELETE FROM orders WHERE id=65')
        self.assertEqual(self.client.get('/account?before=65').status_code,200)
    def test_invalid_cursors(self):
        for value in ('0','-1','abc','9223372036854775808','9'*100,'1.5',''):
            self.assertEqual(self.client.get('/account',query_string={'before':value}).status_code,400)
    def test_migration_and_existing_index(self):
        with sqlite3.connect(self.path) as c:
            c.execute('DELETE FROM schema_migrations')
        create_app(self.config)
        with sqlite3.connect(self.path) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM order_receipts').fetchone()[0],103)
            c.execute('DELETE FROM orders WHERE id=103')
        create_app(self.config)
        with sqlite3.connect(self.path) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM order_receipts').fetchone()[0],103)
            self.assertEqual(c.execute('SELECT last_id FROM order_sequence').fetchone()[0],103)
            self.assertEqual(c.execute('PRAGMA journal_mode').fetchone()[0],'wal')
            plan=c.execute('EXPLAIN QUERY PLAN SELECT id,items FROM orders WHERE user_id=1 AND id<50 ORDER BY id DESC LIMIT 21').fetchall()
            self.assertIn('orders_owner',str(plan))
            self.assertNotIn('TEMP B-TREE',str(plan))
    def test_photo_files_in_release(self):
        from build_release import release_files
        from catalog import PART_IMAGES
        root=Path(__file__).resolve().parents[1]
        selected=set(release_files(root))
        for image in PART_IMAGES.values(): self.assertIn(root/'static'/image,selected)

if __name__=='__main__':unittest.main()
