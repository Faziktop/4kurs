"""Reproducible local-only SQLite and real HTTP load test; never opens the live DB."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import shutil
import sqlite3
import statistics
import sys
import threading
import time
import urllib.request
import urllib.error
from importlib.metadata import version

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import create_app
from catalog import PRESETS, resolve, price
from jinja2 import ChoiceLoader, DictLoader, FileSystemLoader
from waitress import create_server

SECRET = 'benchmark-only-secret-not-for-real-deployment-2026'
SID = 'synthetic-benchmark-session'

def factory(label, database):
    if label == 'before':
        spec = importlib.util.spec_from_file_location('benchmark_baseline', ROOT/'performance/baseline_app.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        make = module.create_app
    else:
        make = create_app
    app = make({'TESTING': True, 'SECRET_KEY': SECRET, 'DATABASE': str(database), 'APP_ENV': 'local'})
    loaders = [FileSystemLoader(str(ROOT/'templates'))]
    if label == 'before':
        loaders.insert(0, DictLoader({'account.html': (ROOT/'performance/baseline_account.html').read_text()}))
    app.jinja_loader = ChoiceLoader(loaders)
    app.static_folder = str(ROOT/'static')
    return app

def seed(path, users=100, orders=150, heavy=51):
    if path.exists():
        raise FileExistsError(f'Refusing to overwrite {path}; choose a fresh --output-dir')
    factory('before', path)
    parts = resolve(PRESETS[0])
    snapshot = json.dumps([{'parts': {k: {'name': v['name'], 'price': v['price']} for k,v in parts.items()}, 'total': price(parts)}], ensure_ascii=False)
    with sqlite3.connect(path) as c:
        c.executemany('INSERT INTO users(id,name,email,password_hash) VALUES(?,?,?,?)',
                      ((i, f'Тестовый покупатель {i}', f'load{i}@example.invalid', '!disabled-test-account!') for i in range(1,users+1)))
        c.executemany('INSERT INTO orders(id,user_id,items,total,phone,address,token) VALUES(?,?,?,?,?,?,?)',
                      ((i, 1 if i<=heavy else 2+(i-heavy-1)%(users-1), snapshot, price(parts), '+70000000000', 'Синтетический адрес, тестовая улица, 1', f'fixture-order-{i}') for i in range(1,orders+1)))
        c.execute('INSERT INTO order_receipts SELECT token,user_id FROM orders')
        c.execute('UPDATE order_sequence SET last_id=?', (orders,))
        c.execute('INSERT INTO auth_sessions VALUES(?,?,?)', (hashlib.sha256(SID.encode()).hexdigest(),1,time.time()+86400))
        c.executemany('INSERT INTO attempts VALUES(?,?)', ((f'fixture-scope-{i%100}',time.time()) for i in range(150)))
        c.executemany('INSERT INTO auth_sessions VALUES(?,?,?)', ((f'fixture-session-{i}',1+i%users,time.time()+86400) for i in range(100)))

def summary(times, elapsed=None):
    values = sorted(times)
    return {'requests': len(values), 'median_ms': round(statistics.median(values),3),
            'p95_ms': round(values[min(len(values)-1, int(len(values)*.95))],3),
            **({'requests_per_second': round(len(values)/elapsed,2)} if elapsed else {})}

def sql_test(path, optimized):
    sql='SELECT id,items,total,phone,address,status,created_at FROM orders WHERE user_id=? AND id<? ORDER BY id DESC LIMIT 21' if optimized else 'SELECT * FROM orders WHERE user_id=? ORDER BY id DESC'
    params=(1,31) if optimized else (1,)
    with sqlite3.connect(path) as c:
        plan=[list(r) for r in c.execute('EXPLAIN QUERY PLAN '+sql,params)]
        times=[]
        for _ in range(100):
            t=time.perf_counter(); rows=c.execute(sql,params).fetchall();times.append((time.perf_counter()-t)*1000)
    return {**summary(times),'rows':len(rows),'plan':plan,'sql':sql}

def http_test(app, concurrency, requests, route='/account'):
    server=create_server(app,host='127.0.0.1',port=0,threads=8)
    thread=threading.Thread(target=server.run,daemon=True);thread.start()
    url=f'http://127.0.0.1:{server.effective_port}{route}'
    cookie=app.session_interface.get_signing_serializer(app).dumps({'sid':SID,'csrf':'a'*64})
    def one(_):
        start=time.perf_counter()
        try:
            req=urllib.request.Request(url,headers={'Cookie': f'session={cookie}'})
            with urllib.request.urlopen(req,timeout=60) as response:
                body=response.read();code=response.status
            valid=code==200 and ('Привет'.encode() in body if route.startswith('/account') else True)
            return ((time.perf_counter()-start)*1000,len(body),0 if valid else 1)
        except Exception as exc:
            return ((time.perf_counter()-start)*1000,0,str(exc))
    try:
        for i in range(3): one(i)
        start=time.perf_counter()
        with ThreadPoolExecutor(max_workers=concurrency) as pool: result=list(pool.map(one,range(requests)))
        elapsed=time.perf_counter()-start
        return {**summary([r[0] for r in result],elapsed),'concurrency':concurrency,
                'errors':[r[2] for r in result if r[2]],'response_bytes':result[0][1]}
    finally:
        server.close();thread.join(timeout=2)

def mixed_sql(path):
    # Isolate SQLite lock behavior: authenticated SELECT + receipt/sequence/order write.
    def worker(i):
        t=time.perf_counter()
        try:
            with sqlite3.connect(path,timeout=15) as c:
                c.execute('PRAGMA foreign_keys=ON')
                if i%4==0:
                    c.execute('BEGIN IMMEDIATE')
                    c.execute('UPDATE order_sequence SET last_id=last_id+1 WHERE singleton=1')
                    oid=c.execute('SELECT last_id FROM order_sequence').fetchone()[0]
                    token=f'mixed-{oid}'
                    c.execute('INSERT INTO order_receipts VALUES(?,1)',(token,))
                    c.execute("INSERT INTO orders(id,user_id,items,total,phone,address,token) VALUES(?,1,'[]',0,'test','test',?)",(oid,token))
                else:
                    c.execute('SELECT id,items FROM orders WHERE user_id=1 ORDER BY id DESC LIMIT 21').fetchall()
            return (time.perf_counter()-t)*1000,None
        except Exception as e: return (time.perf_counter()-t)*1000,str(e)
    start=time.perf_counter()
    with ThreadPoolExecutor(max_workers=16) as pool: result=list(pool.map(worker,range(400)))
    return {**summary([r[0] for r in result],time.perf_counter()-start),'concurrency':16,'writes':100,'errors':[r[1] for r in result if r[1]]}

def checkout_test(app, database):
    """24 real POSTs / 12 unique tokens: concurrent duplicate submissions."""
    import http.client
    from urllib.parse import urlencode
    with sqlite3.connect(database) as c:
        initial=c.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
        for uid in range(2,14):
            c.execute('INSERT INTO auth_sessions VALUES(?,?,?)',
                      (hashlib.sha256(f'checkout-{uid}'.encode()).hexdigest(),uid,time.time()+3600))
    server=create_server(app,host='127.0.0.1',port=0,threads=8)
    thread=threading.Thread(target=server.run,daemon=True);thread.start()
    def one(i):
        uid=2+i//2;token=f'concurrent-checkout-{uid}'
        cookie=app.session_interface.get_signing_serializer(app).dumps(
            {'sid':f'checkout-{uid}','csrf':'a'*64,'checkout_token':token,'cart':[PRESETS[0]]})
        body=urlencode({'csrf_token':'a'*64,'checkout_token':token,'phone':'+70000000000','address':'Тестовый город, улица 1'})
        start=time.perf_counter();conn=http.client.HTTPConnection('127.0.0.1',server.effective_port,timeout=30)
        try:
            conn.request('POST','/checkout',body,{'Cookie':f'session={cookie}','Content-Type':'application/x-www-form-urlencoded'})
            response=conn.getresponse();response.read()
            return (time.perf_counter()-start)*1000,response.status,response.getheader('Location')
        finally:conn.close()
    try:
        start=time.perf_counter()
        with ThreadPoolExecutor(max_workers=12) as pool:result=list(pool.map(one,range(24)))
        elapsed=time.perf_counter()-start
        with sqlite3.connect(database) as c:
            added=c.execute('SELECT COUNT(*) FROM orders').fetchone()[0]-initial
            receipts=c.execute("SELECT COUNT(*) FROM order_receipts WHERE token LIKE 'concurrent-checkout-%'").fetchone()[0]
        return {**summary([r[0] for r in result],elapsed),'concurrency':12,'created_orders':added,
                'receipts':receipts,'expected_unique_orders':12,
                'errors':[list(r[1:]) for r in result if r[1]!=302 or r[2]!='/account'],
                'idempotency_ok':added==receipts==12}
    finally:server.close();thread.join(timeout=2)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path,default=ROOT/'performance/run')
    parser.add_argument('--requests',type=int,default=80)
    args=parser.parse_args()
    if args.requests<1: parser.error('--requests must be positive')
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    fixture=out/'fixture.sqlite3';seed(fixture)
    report={'environment':{'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'platform':platform.platform(),'flask':version('flask'),'waitress':version('waitress'),'server_threads':8},
            'dataset':{'users':100,'orders':150,'orders_heavy_user':51,'attempts':150,'sessions':101},'results':{}}
    for label in ('before','after'):
        print(f'Benchmark {label}',flush=True)
        database=out/f'{label}.sqlite3';shutil.copy2(fixture,database)
        start=time.perf_counter();app=factory(label,database);first=(time.perf_counter()-start)*1000
        startup=[]
        for _ in range(5):
            start=time.perf_counter();factory(label,database);startup.append((time.perf_counter()-start)*1000)
        report['results'][label]={'startup_first_ms':round(first,3),'startup_repeat':summary(startup),
            'sql':sql_test(database,label=='after'),
            'http_account':[http_test(app,c,args.requests) for c in (1,8,16)],
            'http_catalog':http_test(app,8,args.requests,'/'),
            'http_configure':http_test(app,8,args.requests,'/configure'),
            'http_checkout':checkout_test(app,database),
            'mixed_sql':mixed_sql(database)}
        with sqlite3.connect(database) as c:
            report['results'][label]['integrity']=c.execute('PRAGMA integrity_check').fetchone()[0]
            report['results'][label]['foreign_key_errors']=c.execute('PRAGMA foreign_key_check').fetchall()
        (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    # Deliverable fixture has no usable authentication sessions or test rate counters.
    with sqlite3.connect(fixture) as c:
        c.execute('DELETE FROM auth_sessions');c.execute('DELETE FROM attempts')
        c.commit();c.execute('VACUUM')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    for result in report['results'].values():
        assert result['integrity'] == 'ok' and not result['foreign_key_errors']
        assert result['http_checkout']['idempotency_ok']
        for check in result['http_account'] + [result['http_catalog'], result['http_configure'], result['http_checkout'], result['mixed_sql']]:
            assert not check['errors'], check


if __name__=='__main__':main()
