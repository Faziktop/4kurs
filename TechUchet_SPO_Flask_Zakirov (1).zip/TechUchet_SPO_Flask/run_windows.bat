@echo off
chcp 65001 >nul
echo ======================================================================
echo Запуск АИС «ТехУчет-СПО» v1.2 (Разработчик: Закиров И. Р., гр. ИСП 44-9)
echo ======================================================================
if not exist .venv (
    echo Создание виртуального окружения Python...
    python -m venv .venv
)
call .venv\Scripts\activate
pip install -r requirements.txt --quiet
echo Запуск веб-сервера Flask на http://127.0.0.1:5000 ...
start http://127.0.0.1:5000
python app.py
pause
