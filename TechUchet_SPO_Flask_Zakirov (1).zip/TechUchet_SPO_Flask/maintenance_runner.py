# -*- coding: utf-8 -*-
"""
Скрипт регламентного обслуживания и диагностики БД АИС «ТехУчет-СПО» (maintenance_runner.py)
Разработчик: студент гр. ИСП 44-9 Закиров И. Р. (ПМ 06)
"""
import os
import sqlite3
from datetime import datetime

DB_PATH = "tech_inventory.db"
REPORT_FILE = "reports/Журнал_ТО_и_диагностики.txt"


def run_scheduled_maintenance(db_path=DB_PATH, report_file=REPORT_FILE):
    os.makedirs(os.path.dirname(report_file) if os.path.dirname(report_file) else ".", exist_ok=True)
    size_before_kb = os.path.getsize(db_path) / 1024.0 if os.path.exists(db_path) else 0.0

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    integrity = cur.execute("PRAGMA integrity_check;").fetchone()[0]
    fk_violations = cur.execute("PRAGMA foreign_key_check;").fetchall()

    total_eq = cur.execute("SELECT COUNT(*) FROM equipment;").fetchone()[0]
    in_use = cur.execute("SELECT COUNT(*) FROM equipment WHERE status = 'В эксплуатации';").fetchone()[0]
    in_repair = cur.execute("SELECT COUNT(*) FROM equipment WHERE status = 'В ремонте';").fetchone()[0]
    in_stock = cur.execute("SELECT COUNT(*) FROM equipment WHERE status = 'На складе';").fetchone()[0]
    written_off = cur.execute("SELECT COUNT(*) FROM equipment WHERE status = 'Списано';").fetchone()[0]
    open_reqs = cur.execute(
        "SELECT COUNT(*) FROM maintenance_requests WHERE status IN ('Открыта', 'В работе');"
    ).fetchone()[0]

    conn.execute("REINDEX;")
    conn.execute("VACUUM;")
    conn.execute("ANALYZE;")
    conn.close()

    size_after_kb = os.path.getsize(db_path) / 1024.0 if os.path.exists(db_path) else 0.0

    lines = [
        "==========================================================================",
        "ПРОТОКОЛ РЕГЛАМЕНТНОГО ОБСЛУЖИВАНИЯ И ДИАГНОСТИКИ АИС «ТехУчет-СПО» v1.2",
        f"Дата и время проведения: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "Исполнитель: Закиров И. Р. (группа ИСП 44-9)",
        "Руководитель практики: Шадрина Арина Юрьевна",
        "==========================================================================",
        f"1. Физическая целостность страниц БД (PRAGMA integrity_check): {integrity.upper()}",
        f"2. Нарушения ссылочной целостности (PRAGMA foreign_key_check): {len(fk_violations)} шт.",
        f"3. Контроль реестра техники: всего {total_eq} ед. (в эксплуатации: {in_use}, "
        f"на складе: {in_stock}, в ремонте: {in_repair}, списано: {written_off})",
        f"4. Активные заявки на ремонт и ТО в очереди: {open_reqs} шт.",
        f"5. Оптимизация (REINDEX, VACUUM, ANALYZE): ВЫПОЛНЕНО УСПЕШНО "
        f"(размер БД до сжатия: {size_before_kb:.1f} КБ, после сжатия: {size_after_kb:.1f} КБ)",
        "=========================================================================="
    ]
    report_text = "\n".join(lines)
    with open(report_file, "w", encoding="utf-8") as f:
        f.write(report_text + "\n")
    return report_text


if __name__ == "__main__":
    print(run_scheduled_maintenance())
