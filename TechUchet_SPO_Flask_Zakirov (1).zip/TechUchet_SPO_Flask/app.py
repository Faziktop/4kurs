# -*- coding: utf-8 -*-
"""
Веб-приложение АИС «ТехУчет-СПО» v1.2 на фреймворке Flask (app.py)
С поддержкой авторизации, смены учетной записи и разграничения прав по 4 ролям (ТБ-01)
Разработчик: студент гр. ИСП 44-9 Закиров И. Р. (ПМ 06)
Руководитель учебной практики: Шадрина Арина Юрьевна
"""
import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session

from tech_inventory_core import TechInventoryIS
from backup_service import create_system_backup, restore_system_backup, read_backup_manifest
from maintenance_runner import run_scheduled_maintenance
from seed_data import seed_database

app = Flask(__name__)
app.secret_key = "tech-uchet-spo-zakirov-secret-key-2026"

DB_PATH = "tech_inventory.db"
if not os.path.exists(DB_PATH):
    seed_database(DB_PATH, "schema.sql")
    create_system_backup(DB_PATH, "backups", backup_type="DAILY")
    run_scheduled_maintenance(DB_PATH, "reports/Журнал_ТО_и_диагностики.txt")

core = TechInventoryIS(DB_PATH)

# Built-in user accounts corresponding to the 4 roles in Table 8 of the GOST documentation
USER_ACCOUNTS = {
    "admin": {
        "login": "admin",
        "password": "123",
        "full_name": "Закиров И. Р.",
        "role": "Администратор ИС",
        "department": "ИТ-отдел (полный доступ)",
        "can_add": True,
        "can_move": True,
        "can_request": True,
        "can_close_request": True,
        "can_admin": True,
    },
    "operator": {
        "login": "operator",
        "password": "123",
        "full_name": "Иванов С. П.",
        "role": "Оператор учета (Лаборант ИТ)",
        "department": "Отделение ИТ (реестр и перемещения)",
        "can_add": True,
        "can_move": True,
        "can_request": True,
        "can_close_request": False,
        "can_admin": False,
    },
    "engineer": {
        "login": "engineer",
        "password": "123",
        "full_name": "Петров А. В.",
        "role": "Инженер по ремонту и ТО",
        "department": "ИТ-отдел (ремонт и обслуживание)",
        "can_add": False,
        "can_move": False,
        "can_request": True,
        "can_close_request": True,
        "can_admin": False,
    },
    "mol": {
        "login": "mol",
        "password": "123",
        "full_name": "Смирнова Е. В.",
        "role": "Материально ответственное лицо (МОЛ)",
        "department": "Зав. лаб. 212 (просмотр, заявки, описи)",
        "can_add": False,
        "can_move": False,
        "can_request": True,
        "can_close_request": False,
        "can_admin": False,
    },
}


def get_current_user():
    login_key = session.get("user_login", "admin")
    return USER_ACCOUNTS.get(login_key, USER_ACCOUNTS["admin"])


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        login_key = request.form.get("login", "").strip()
        password = request.form.get("password", "").strip()
        user = USER_ACCOUNTS.get(login_key)
        if user and (not password or password == user["password"]):
            session["user_login"] = login_key
            flash(f"Выполнен вход в учетную запись: {user['full_name']} (Роль: {user['role']}).", "success")
            return redirect(url_for("index"))
        flash("Неверный логин или пароль. Попробуйте снова или выберите профиль из списка.", "danger")
    return render_template("login.html", accounts=USER_ACCOUNTS, current_user=get_current_user())


@app.route("/switch_account/<login_key>")
def switch_account(login_key):
    if login_key in USER_ACCOUNTS:
        session["user_login"] = login_key
        u = USER_ACCOUNTS[login_key]
        flash(f"Аккаунт переключен: {u['full_name']} — роль «{u['role']}».", "success")
    return redirect(request.referrer or url_for("index"))


@app.route("/logout")
def logout():
    session.pop("user_login", None)
    flash("Вы вышли из текущей сессии. Выберите учетную запись для входа.", "warning")
    return redirect(url_for("login"))


@app.route("/")
def index():
    current_user = get_current_user()
    tab = request.args.get("tab", "registry")
    search_q = request.args.get("q", "").strip()
    status_f = request.args.get("status", "Все")
    cat_f = request.args.get("category", "Все")
    bldg_f = request.args.get("building", "Все")

    kpi = core.get_kpi_summary()
    equipment_list = core.get_all_equipment(
        search_query=search_q,
        status_filter=status_f,
        category_filter=cat_f,
        building_filter=bldg_f,
    )
    categories = core.get_categories()
    rooms = core.get_rooms()
    employees = core.get_employees()
    movements = core.get_movements()
    requests_list = core.get_service_requests()
    analytics = core.get_analytics_breakdown()
    manifest_logs = read_backup_manifest("backups")

    maint_report = ""
    report_path = "reports/Журнал_ТО_и_диагностики.txt"
    if os.path.exists(report_path):
        with open(report_path, "r", encoding="utf-8") as rf:
            maint_report = rf.read()

    backup_files = []
    if os.path.exists("backups"):
        backup_files = sorted(
            [f for f in os.listdir("backups") if f.endswith(".zip")],
            reverse=True
        )

    return render_template(
        "index.html",
        current_user=current_user,
        accounts=USER_ACCOUNTS,
        active_tab=tab,
        search_q=search_q,
        status_f=status_f,
        cat_f=cat_f,
        bldg_f=bldg_f,
        kpi=kpi,
        equipment_list=equipment_list,
        categories=categories,
        rooms=rooms,
        employees=employees,
        movements=movements,
        requests_list=requests_list,
        analytics=analytics,
        manifest_logs=manifest_logs,
        maint_report=maint_report,
        backup_files=backup_files,
        today_date=datetime.now().strftime("%Y-%m-%d"),
    )


@app.route("/equipment/add", methods=["POST"])
def add_equipment():
    user = get_current_user()
    if not user["can_add"]:
        flash(f"Отказ в доступе (ТБ-01): роль «{user['role']}» не имеет прав на регистрацию новых карточек техники.", "danger")
        return redirect(url_for("index", tab="registry"))
    try:
        new_id = core.register_equipment(
            inv_number=request.form["inv_number"],
            serial_number=request.form["serial_number"],
            title=request.form["title"],
            category_id=request.form["category_id"],
            room_id=request.form["room_id"],
            mol_id=request.form["mol_id"],
            purchase_date=request.form["purchase_date"],
            warranty_until=request.form.get("warranty_until", ""),
            cost_rub=request.form["cost_rub"],
            specs=request.form.get("specs", ""),
            status=request.form.get("status", "В эксплуатации"),
        )
        flash(f"Карточка оборудования успешно зарегистрирована в БД (ID={new_id}, инв. № {request.form['inv_number']}).", "success")
    except Exception as e:
        flash(f"Ошибка при регистрации оборудования: {e}", "danger")
    return redirect(url_for("index", tab="registry"))


@app.route("/equipment/move", methods=["POST"])
def move_equipment_route():
    user = get_current_user()
    if not user["can_move"]:
        flash(f"Отказ в доступе (ТБ-01): роль «{user['role']}» не имеет прав на проведение актов перемещения.", "danger")
        return redirect(url_for("index", tab="movements"))
    try:
        core.move_equipment(
            equipment_id=request.form["equipment_id"],
            to_room_id=request.form["to_room_id"],
            to_mol_id=request.form["to_mol_id"],
            doc_basis=request.form["doc_basis"],
        )
        flash("Акт внутреннего перемещения успешно проведен. История сохранена в журнале movement_history.", "success")
    except Exception as e:
        flash(f"Ошибка оформления перемещения: {e}", "danger")
    return redirect(url_for("index", tab=request.form.get("return_tab", "movements")))


@app.route("/requests/create", methods=["POST"])
def create_request_route():
    try:
        req_id = core.create_service_request(
            equipment_id=request.form["equipment_id"],
            issue_type=request.form["issue_type"],
            description=request.form["description"],
            engineer_name=request.form["engineer_name"],
        )
        flash(f"Заявка на ремонт № {req_id} зарегистрирована. Статус техники автоматически изменен на «В ремонте».", "warning")
    except Exception as e:
        flash(f"Ошибка создания заявки: {e}", "danger")
    return redirect(url_for("index", tab="requests"))


@app.route("/requests/close", methods=["POST"])
def close_request_route():
    user = get_current_user()
    if not user["can_close_request"]:
        flash(f"Отказ в доступе (ТБ-01): роль «{user['role']}» не имеет прав на закрытие заявок на ремонт.", "danger")
        return redirect(url_for("index", tab="requests"))
    try:
        core.close_service_request(
            request_id=request.form["request_id"],
            resolution=request.form["resolution"],
            final_eq_status=request.form.get("final_eq_status", "В эксплуатации"),
        )
        flash(f"Заявка № {request.form['request_id']} закрыта со статусом «Выполнена». Оборудование возвращено в строй.", "success")
    except Exception as e:
        flash(f"Ошибка закрытия заявки: {e}", "danger")
    return redirect(url_for("index", tab="requests"))


@app.route("/admin/backup", methods=["POST"])
def trigger_backup():
    user = get_current_user()
    if not user["can_admin"]:
        flash(f"Отказ в доступе (ТБ-01): операция резервного копирования доступна только роли «Администратор ИС».", "danger")
        return redirect(url_for("index", tab="backup"))
    try:
        b_type = request.form.get("backup_type", "DAILY")
        archive_path, sha256_hash = create_system_backup(DB_PATH, "backups", backup_type=b_type)
        flash(f"Горячая резервная копия создана: {os.path.basename(archive_path)} (SHA-256: {sha256_hash[:24]}...).", "success")
    except Exception as e:
        flash(f"Ошибка резервного копирования: {e}", "danger")
    return redirect(url_for("index", tab="backup"))


@app.route("/admin/restore", methods=["POST"])
def trigger_restore():
    user = get_current_user()
    if not user["can_admin"]:
        flash(f"Отказ в доступе (ТБ-01): аварийное восстановление БД доступно только роли «Администратор ИС».", "danger")
        return redirect(url_for("index", tab="backup"))
    try:
        zip_name = request.form.get("zip_filename", "")
        expected_hash = request.form.get("expected_sha256", "").strip() or None
        zip_path = os.path.join("backups", zip_name)
        restore_system_backup(zip_path, DB_PATH, expected_sha256=expected_hash)
        flash(f"База данных успешно восстановлена из архива {zip_name}. Проверка PRAGMA integrity_check: OK.", "success")
    except Exception as e:
        flash(f"Ошибка аварийного восстановления БД: {e}", "danger")
    return redirect(url_for("index", tab="backup"))


@app.route("/admin/maintenance", methods=["POST"])
def trigger_maintenance():
    user = get_current_user()
    if not user["can_admin"]:
        flash(f"Отказ в доступе (ТБ-01): регламентное обслуживание СУБД доступно только роли «Администратор ИС».", "danger")
        return redirect(url_for("index", tab="backup"))
    try:
        run_scheduled_maintenance(DB_PATH, "reports/Журнал_ТО_и_диагностики.txt")
        flash("Регламентное обслуживание БД (PRAGMA integrity_check, foreign_key_check, REINDEX, VACUUM, ANALYZE) выполнено успешно.", "success")
    except Exception as e:
        flash(f"Ошибка обслуживания БД: {e}", "danger")
    return redirect(url_for("index", tab="backup"))


@app.route("/export/csv")
def export_csv():
    room_num = request.args.get("room", None)
    out_file = os.path.abspath("reports/Инвентаризационная_ведомость.csv")
    core.export_inventory_sheet(out_file, room_number=room_num)
    return send_file(
        out_file,
        mimetype="text/csv",
        as_attachment=True,
        download_name="Инвентаризационная_ведомость_ТехУчет_СПО.csv",
    )


if __name__ == "__main__":
    print("======================================================================")
    print("АИС «ТехУчет-СПО» v1.2 (Flask) запущена: http://127.0.0.1:5000")
    print("Страница входа и смены аккаунта:        http://127.0.0.1:5000/login")
    print("Разработчик: студент гр. ИСП 44-9 Закиров И. Р.")
    print("======================================================================")
    app.run(host="127.0.0.1", port=5000, debug=False)
