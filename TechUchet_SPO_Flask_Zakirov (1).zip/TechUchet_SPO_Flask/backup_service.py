# -*- coding: utf-8 -*-
"""
Сервис резервного копирования и аварийного восстановления АИС «ТехУчет-СПО» (backup_service.py)
Разработчик: студент гр. ИСП 44-9 Закиров И. Р. (ПМ 06)
"""
import os
import shutil
import sqlite3
import zipfile
import hashlib
from datetime import datetime

DB_SOURCE = "tech_inventory.db"
BACKUP_DIR = "backups"


def calculate_sha256(file_path):
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def create_system_backup(db_source=DB_SOURCE, backup_dir=BACKUP_DIR, backup_type="DAILY"):
    os.makedirs(backup_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    hot_db_copy = os.path.join(backup_dir, f"tech_inventory_{ts}.db")
    sql_dump_file = os.path.join(backup_dir, f"dump_{ts}.sql")
    zip_archive = os.path.join(backup_dir, f"backup_tech_inventory_{ts}.zip")

    # 1. Горячее копирование рабочей БД через SQLite Online Backup API
    src_conn = sqlite3.connect(db_source)
    dst_conn = sqlite3.connect(hot_db_copy)
    with dst_conn:
        src_conn.backup(dst_conn)
    dst_conn.close()

    # 2. Выгрузка полного текстового SQL-дампа (iterdump)
    with open(sql_dump_file, "w", encoding="utf-8") as f:
        for line in src_conn.iterdump():
            f.write(f"{line}\n")
    src_conn.close()

    # 3. Упаковка бинарной копии БД и SQL-дампа в сжатый ZIP-архив
    with zipfile.ZipFile(zip_archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.write(hot_db_copy, arcname="tech_inventory.db")
        zf.write(sql_dump_file, arcname=f"dump_{ts}.sql")

    os.remove(hot_db_copy)
    os.remove(sql_dump_file)

    # 4. Расчет эталонной контрольной суммы SHA-256 и запись в манифест
    sha256_hash = calculate_sha256(zip_archive)
    size_kb = os.path.getsize(zip_archive) / 1024.0
    manifest_path = os.path.join(backup_dir, "backup_manifest.log")
    with open(manifest_path, "a", encoding="utf-8") as log:
        log.write(
            f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] TYPE={backup_type:<9} "
            f"ARCHIVE={os.path.basename(zip_archive)} SIZE={size_kb:.1f}KB "
            f"SHA256={sha256_hash} STATUS=OK\n"
        )
    return zip_archive, sha256_hash


def restore_system_backup(zip_archive_path, target_db_path=DB_SOURCE, expected_sha256=None):
    if not os.path.exists(zip_archive_path):
        raise FileNotFoundError(f"Архив резервной копии не найден: {zip_archive_path}")

    actual_sha256 = calculate_sha256(zip_archive_path)
    if expected_sha256 and actual_sha256.lower() != expected_sha256.lower():
        raise ValueError("КРИТИЧЕСКАЯ ОШИБКА: Контрольная сумма SHA-256 архива не совпадает с эталоном!")

    if os.path.exists(target_db_path):
        shutil.copy2(target_db_path, target_db_path + ".corrupted.bak")

    dest_dir = os.path.dirname(os.path.abspath(target_db_path)) or "."
    with zipfile.ZipFile(zip_archive_path, "r") as zf:
        zf.extract("tech_inventory.db", path=dest_dir)

    conn = sqlite3.connect(target_db_path)
    integrity = conn.execute("PRAGMA integrity_check;").fetchone()[0]
    fk_errors = conn.execute("PRAGMA foreign_key_check;").fetchall()
    conn.close()
    if integrity.lower() != "ok" or len(fk_errors) > 0:
        raise RuntimeError(f"Ошибка верификации восстановленной БД: integrity={integrity}")
    return True


def read_backup_manifest(backup_dir=BACKUP_DIR):
    manifest_path = os.path.join(backup_dir, "backup_manifest.log")
    if not os.path.exists(manifest_path):
        return []
    with open(manifest_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]
    return list(reversed(lines))


if __name__ == "__main__":
    archive_path, checksum = create_system_backup(backup_type="DAILY")
    print(f"Резервная копия успешно создана: {archive_path}")
    print(f"Контрольная сумма SHA-256: {checksum}")
