-- Файл: schema.sql | Скрипт инициализации БД АИС «ТехУчет-СПО» v1.2
-- Разработчик: студент гр. ИСП 44-9 Закиров И. Р. (ПМ 06)
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = DELETE;

CREATE TABLE IF NOT EXISTS categories (
    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    norm_life_years INTEGER NOT NULL DEFAULT 5 CHECK(norm_life_years > 0)
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_number TEXT NOT NULL UNIQUE,
    building TEXT NOT NULL DEFAULT 'Корпус №1',
    department TEXT NOT NULL,
    workplaces_count INTEGER NOT NULL DEFAULT 15 CHECK(workplaces_count >= 0)
);

CREATE TABLE IF NOT EXISTS employees (
    employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    position TEXT NOT NULL,
    department TEXT NOT NULL,
    phone TEXT,
    is_mol INTEGER NOT NULL DEFAULT 1 CHECK(is_mol IN (0, 1))
);

CREATE TABLE IF NOT EXISTS equipment (
    equipment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    inv_number TEXT NOT NULL UNIQUE,
    serial_number TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    category_id INTEGER NOT NULL REFERENCES categories(category_id) ON DELETE RESTRICT,
    room_id INTEGER NOT NULL REFERENCES rooms(room_id) ON DELETE RESTRICT,
    mol_id INTEGER NOT NULL REFERENCES employees(employee_id) ON DELETE RESTRICT,
    purchase_date TEXT NOT NULL,
    warranty_until TEXT,
    cost_rub REAL NOT NULL CHECK(cost_rub >= 0),
    specs TEXT,
    status TEXT NOT NULL CHECK(status IN ('В эксплуатации', 'В ремонте', 'На складе', 'Списано'))
);

CREATE TABLE IF NOT EXISTS movement_history (
    move_id INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id INTEGER NOT NULL REFERENCES equipment(equipment_id) ON DELETE CASCADE,
    from_room_id INTEGER REFERENCES rooms(room_id),
    to_room_id INTEGER NOT NULL REFERENCES rooms(room_id),
    from_mol_id INTEGER REFERENCES employees(employee_id),
    to_mol_id INTEGER NOT NULL REFERENCES employees(employee_id),
    move_date TEXT NOT NULL,
    doc_basis TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS maintenance_requests (
    request_id INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id INTEGER NOT NULL REFERENCES equipment(equipment_id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    closed_at TEXT,
    issue_type TEXT NOT NULL,
    description TEXT NOT NULL,
    engineer_name TEXT NOT NULL,
    resolution TEXT,
    status TEXT NOT NULL CHECK(status IN ('Открыта', 'В работе', 'Выполнена', 'Отклонена'))
);

CREATE INDEX IF NOT EXISTS idx_equipment_status ON equipment(status);
CREATE INDEX IF NOT EXISTS idx_equipment_room ON equipment(room_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON maintenance_requests(status);
