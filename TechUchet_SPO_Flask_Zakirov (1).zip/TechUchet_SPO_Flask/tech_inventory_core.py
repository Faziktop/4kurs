# -*- coding: utf-8 -*-
"""
Модуль ядра бизнес-логики АИС «ТехУчет-СПО» (tech_inventory_core.py)
Разработчик: студент гр. ИСП 44-9 Закиров И. Р. (ПМ 06)
"""
import os
import csv
import sqlite3
from datetime import datetime


class TechInventoryIS:
    def __init__(self, db_path="tech_inventory.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.execute("PRAGMA journal_mode = DELETE;")

    def init_schema(self, schema_file="schema.sql"):
        if os.path.exists(schema_file):
            with open(schema_file, "r", encoding="utf-8") as f:
                self.conn.executescript(f.read())
            self.conn.commit()

    def get_kpi_summary(self):
        cur = self.conn.cursor()
        total = cur.execute("SELECT COUNT(*), COALESCE(SUM(cost_rub), 0) FROM equipment").fetchone()
        by_status = dict(cur.execute("SELECT status, COUNT(*) FROM equipment GROUP BY status").fetchall())
        open_reqs = cur.execute(
            "SELECT COUNT(*) FROM maintenance_requests WHERE status IN ('Открыта', 'В работе')"
        ).fetchone()[0]
        total_moves = cur.execute("SELECT COUNT(*) FROM movement_history").fetchone()[0]
        total_reqs = cur.execute("SELECT COUNT(*) FROM maintenance_requests").fetchone()[0]
        cnt = total[0] if total[0] > 0 else 1
        return {
            "total_count": total[0],
            "total_cost": round(total[1], 2),
            "total_cost_mln": round(total[1] / 1_000_000, 2),
            "in_use": by_status.get("В эксплуатации", 0),
            "in_use_pct": round(by_status.get("В эксплуатации", 0) * 100.0 / cnt, 1),
            "in_stock": by_status.get("На складе", 0),
            "in_stock_pct": round(by_status.get("На складе", 0) * 100.0 / cnt, 1),
            "in_repair": by_status.get("В ремонте", 0),
            "in_repair_pct": round(by_status.get("В ремонте", 0) * 100.0 / cnt, 1),
            "written_off": by_status.get("Списано", 0),
            "written_off_pct": round(by_status.get("Списано", 0) * 100.0 / cnt, 1),
            "open_requests": open_reqs,
            "total_moves": total_moves,
            "total_requests": total_reqs,
        }

    def get_all_equipment(self, search_query="", status_filter="Все", category_filter="Все", building_filter="Все"):
        sql = """
            SELECT e.equipment_id, e.inv_number, e.serial_number, e.title,
                   e.category_id, c.name AS category_name,
                   e.room_id, r.room_number, r.building,
                   e.mol_id, m.full_name AS mol_name,
                   e.purchase_date, e.warranty_until,
                   e.cost_rub, e.specs, e.status
            FROM equipment e
            JOIN categories c ON e.category_id = c.category_id
            JOIN rooms r ON e.room_id = r.room_id
            JOIN employees m ON e.mol_id = m.employee_id
            WHERE 1=1
        """
        params = []
        if search_query:
            sql += " AND (e.inv_number LIKE ? OR e.serial_number LIKE ? OR e.title LIKE ? OR r.room_number LIKE ? OR m.full_name LIKE ?)"
            pattern = f"%{search_query.strip()}%"
            params.extend([pattern, pattern, pattern, pattern, pattern])
        if status_filter and status_filter != "Все":
            sql += " AND e.status = ?"
            params.append(status_filter)
        if category_filter and category_filter != "Все":
            sql += " AND c.name = ?"
            params.append(category_filter)
        if building_filter and building_filter != "Все":
            sql += " AND r.building = ?"
            params.append(building_filter)
        sql += " ORDER BY e.equipment_id ASC"
        rows = self.conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def get_categories(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM categories ORDER BY category_id").fetchall()]

    def get_rooms(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM rooms ORDER BY room_id").fetchall()]

    def get_employees(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM employees ORDER BY employee_id").fetchall()]

    def register_equipment(self, inv_number, serial_number, title, category_id,
                           room_id, mol_id, purchase_date, warranty_until,
                           cost_rub, specs, status="В эксплуатации"):
        sql = """
            INSERT INTO equipment (
                inv_number, serial_number, title, category_id, room_id, mol_id,
                purchase_date, warranty_until, cost_rub, specs, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cur = self.conn.cursor()
        cur.execute(sql, (
            inv_number.strip(), serial_number.strip(), title.strip(),
            int(category_id), int(room_id), int(mol_id),
            purchase_date, warranty_until, float(cost_rub), specs, status
        ))
        self.conn.commit()
        return cur.lastrowid

    def move_equipment(self, equipment_id, to_room_id, to_mol_id, doc_basis):
        cur = self.conn.cursor()
        eq = cur.execute(
            "SELECT room_id, mol_id, status FROM equipment WHERE equipment_id = ?",
            (int(equipment_id),)
        ).fetchone()
        if not eq:
            raise ValueError("Оборудование с указанным идентификатором не найдено в БД.")
        if eq["status"] == "Списано":
            raise ValueError("Перемещение списанного оборудования запрещено регламентом.")
        move_date = datetime.now().strftime("%Y-%m-%d")
        cur.execute("""
            INSERT INTO movement_history (
                equipment_id, from_room_id, to_room_id, from_mol_id, to_mol_id, move_date, doc_basis
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (int(equipment_id), eq["room_id"], int(to_room_id),
              eq["mol_id"], int(to_mol_id), move_date, doc_basis.strip()))
        cur.execute(
            "UPDATE equipment SET room_id = ?, mol_id = ? WHERE equipment_id = ?",
            (int(to_room_id), int(to_mol_id), int(equipment_id))
        )
        self.conn.commit()

    def get_movements(self):
        sql = """
            SELECT mh.move_id, e.equipment_id, e.inv_number, e.title,
                   r_from.room_number AS from_room, r_to.room_number AS to_room,
                   m_from.full_name AS from_mol, m_to.full_name AS to_mol,
                   mh.move_date, mh.doc_basis
            FROM movement_history mh
            JOIN equipment e ON mh.equipment_id = e.equipment_id
            LEFT JOIN rooms r_from ON mh.from_room_id = r_from.room_id
            JOIN rooms r_to ON mh.to_room_id = r_to.room_id
            LEFT JOIN employees m_from ON mh.from_mol_id = m_from.employee_id
            JOIN employees m_to ON mh.to_mol_id = m_to.employee_id
            ORDER BY mh.move_id DESC
        """
        return [dict(r) for r in self.conn.execute(sql).fetchall()]

    def create_service_request(self, equipment_id, issue_type, description, engineer_name):
        now_ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO maintenance_requests (
                equipment_id, created_at, issue_type, description, engineer_name, status
            ) VALUES (?, ?, ?, ?, ?, 'В работе')
        """, (int(equipment_id), now_ts, issue_type.strip(), description.strip(), engineer_name.strip()))
        cur.execute("UPDATE equipment SET status = 'В ремонте' WHERE equipment_id = ?", (int(equipment_id),))
        self.conn.commit()
        return cur.lastrowid

    def close_service_request(self, request_id, resolution, final_eq_status="В эксплуатации"):
        now_ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        cur = self.conn.cursor()
        req = cur.execute(
            "SELECT equipment_id FROM maintenance_requests WHERE request_id = ?",
            (int(request_id),)
        ).fetchone()
        if not req:
            raise ValueError("Заявка на ремонт с указанным ID не найдена.")
        cur.execute("""
            UPDATE maintenance_requests
            SET closed_at = ?, resolution = ?, status = 'Выполнена'
            WHERE request_id = ?
        """, (now_ts, resolution.strip(), int(request_id)))
        cur.execute(
            "UPDATE equipment SET status = ? WHERE equipment_id = ?",
            (final_eq_status, req["equipment_id"])
        )
        self.conn.commit()

    def get_service_requests(self):
        sql = """
            SELECT mr.request_id, e.equipment_id, e.inv_number, e.title, r.room_number,
                   mr.created_at, mr.closed_at, mr.issue_type, mr.description,
                   mr.engineer_name, mr.resolution, mr.status
            FROM maintenance_requests mr
            JOIN equipment e ON mr.equipment_id = e.equipment_id
            JOIN rooms r ON e.room_id = r.room_id
            ORDER BY mr.request_id DESC
        """
        return [dict(r) for r in self.conn.execute(sql).fetchall()]

    def get_analytics_breakdown(self):
        by_cat = self.conn.execute("""
            SELECT c.name AS category_name, c.norm_life_years,
                   COUNT(e.equipment_id) AS total_units,
                   SUM(CASE WHEN r.building = 'Корпус №1' THEN 1 ELSE 0 END) AS korpus_1,
                   SUM(CASE WHEN r.building = 'Корпус №2' THEN 1 ELSE 0 END) AS korpus_2,
                   ROUND(COALESCE(SUM(e.cost_rub), 0), 2) AS total_cost
            FROM categories c
            LEFT JOIN equipment e ON c.category_id = e.category_id
            LEFT JOIN rooms r ON e.room_id = r.room_id
            GROUP BY c.category_id
            ORDER BY total_units DESC
        """).fetchall()

        by_room = self.conn.execute("""
            SELECT r.room_number, r.building, r.department, r.workplaces_count,
                   COUNT(e.equipment_id) AS eq_count,
                   ROUND(COALESCE(SUM(e.cost_rub), 0), 2) AS room_cost
            FROM rooms r
            LEFT JOIN equipment e ON r.room_id = e.room_id
            GROUP BY r.room_id
            ORDER BY eq_count DESC
        """).fetchall()

        return {
            "by_category": [dict(r) for r in by_cat],
            "by_room": [dict(r) for r in by_room],
        }

    def export_inventory_sheet(self, output_csv="reports/Инвентаризационная_ведомость.csv", room_number=None):
        os.makedirs(os.path.dirname(output_csv) if os.path.dirname(output_csv) else ".", exist_ok=True)
        query = """
            SELECT e.inv_number, e.serial_number, e.title, c.name AS category,
                   r.room_number, r.building, m.full_name AS mol_name,
                   e.purchase_date, e.cost_rub, e.status
            FROM equipment e
            JOIN categories c ON e.category_id = c.category_id
            JOIN rooms r ON e.room_id = r.room_id
            JOIN employees m ON e.mol_id = m.employee_id
        """
        params = ()
        if room_number and room_number != "Все":
            query += " WHERE r.room_number = ?"
            params = (room_number,)
        query += " ORDER BY e.inv_number ASC"
        rows = self.conn.execute(query, params).fetchall()
        with open(output_csv, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(["Инв. номер", "Серийный номер", "Наименование", "Категория",
                             "Аудитория", "Корпус", "МОЛ", "Дата ввода", "Стоимость (руб.)", "Статус"])
            for r in rows:
                writer.writerow(list(r))
        return len(rows)

    def close(self):
        self.conn.close()
