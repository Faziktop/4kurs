'use strict';
const form = document.querySelector('#config-form');
if (form) {
  const parts = JSON.parse(document.querySelector('#parts-data').textContent);
  const total = document.querySelector('#total');
  const box = document.querySelector('#compatibility');
  const button = document.querySelector('#add-button');
  const rub = value => new Intl.NumberFormat('ru-RU').format(value) + ' ₽';
  // Native selects remain the form source and no-JavaScript fallback.
  const pickers = [...form.querySelectorAll('.part-picker')];
  const closePicker = picker => {
    picker.querySelector('.part-options').hidden = true;
    picker.querySelector('.part-trigger').setAttribute('aria-expanded', 'false');
  };
  pickers.forEach(picker => {
    const select = picker.querySelector('select');
    const trigger = picker.querySelector('.part-trigger');
    const list = picker.querySelector('.part-options');
    const options = [...list.querySelectorAll('.part-option')];
    const sync = () => {
      const selected = options.find(option => option.dataset.value === select.value);
      options.forEach(option => option.setAttribute('aria-selected', String(option === selected)));
      const photo = selected.querySelector('.part-photo').cloneNode(true);
      photo.querySelector('img').loading = 'eager';
      const copy = selected.querySelector('.part-copy').cloneNode(true);
      copy.id = 'chosen-' + select.id;
      const arrow = document.createElement('span');
      arrow.className = 'part-chevron';
      arrow.setAttribute('aria-hidden', 'true');
      arrow.textContent = '⌄';
      trigger.replaceChildren(photo, copy, arrow);
    };
    const open = () => {
      pickers.forEach(other => { if (other !== picker) closePicker(other); });
      list.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      options.find(option => option.dataset.value === select.value).focus({preventScroll:true});
    };
    const choose = option => {
      select.value = option.dataset.value;
      sync(); closePicker(picker); trigger.focus({preventScroll:true});
      select.dispatchEvent(new Event('change', {bubbles:true}));
    };
    trigger.addEventListener('click', () => list.hidden ? open() : closePicker(picker));
    trigger.addEventListener('keydown', event => {
      if (['ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); open(); }
    });
    options.forEach((option, index) => {
      option.addEventListener('click', () => choose(option));
      option.addEventListener('keydown', event => {
        if (['Enter', ' '].includes(event.key)) { event.preventDefault(); choose(option); }
        else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
          event.preventDefault();
          const next = event.key === 'Home' ? 0 : event.key === 'End' ? options.length - 1 : (index + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length;
          options[next].focus();
        }
      });
    });
    picker.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); closePicker(picker); trigger.focus(); }
    });
    picker.addEventListener('focusout', event => {
      if (!picker.contains(event.relatedTarget)) closePicker(picker);
    });
    select.addEventListener('change', sync);
    sync(); select.hidden = true; trigger.hidden = false;
    trigger.id = 'picker-' + select.id;
    document.querySelector('#label-' + select.id).htmlFor = trigger.id;
  });
  document.addEventListener('click', event => {
    pickers.forEach(picker => { if (!picker.contains(event.target)) closePicker(picker); });
  });
  let controller;
  async function update() {
    if (controller) controller.abort();
    controller = new AbortController();
    button.disabled = true;
    total.textContent = '…';
    box.textContent = 'Проверяем совместимость…';
    box.className = 'compatibility';
    document.querySelector('#watts').textContent = '';
    for (const [key, options] of Object.entries(parts)) {
      const item = options.find(p => p.id === form.elements[key].value);
      document.querySelector('#detail-' + key).textContent = item.detail;
    }
    try {
      const response = await fetch('/api/quote', {method:'POST', body:new FormData(form), signal:controller.signal});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Не удалось обновить цену');
      total.textContent = rub(data.total);
      box.className = 'compatibility ' + (data.errors.length ? 'incompatible' : 'compatible');
      box.replaceChildren();
      if (data.errors.length) {
        const heading = document.createElement('strong');
        heading.textContent = 'Нужно изменить сборку';
        const list = document.createElement('ul');
        data.errors.forEach(message => { const li = document.createElement('li'); li.textContent = message; list.append(li); });
        box.append(heading, list);
      } else {
        box.textContent = '✓ Основные параметры совместимы';
        button.disabled = false;
      }
      document.querySelector('#watts').textContent = 'Расчётная мощность БП с запасом: от ' + data.watts + ' Вт';
    } catch (error) {
      if (error.name === 'AbortError') return;
      box.textContent = 'Не удалось проверить сборку. Обновите страницу или выберите детали ещё раз.';
      box.className = 'compatibility incompatible';
    }
  }
  form.addEventListener('change', update);
  update();
}
