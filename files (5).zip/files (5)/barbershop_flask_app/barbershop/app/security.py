"""
Простая защита от DDoS/спам-атак: скользящее окно + временный бан IP.
Хранит данные в памяти процесса. Для продакшена замените на Redis.
"""
import time
from collections import defaultdict

from flask import request, abort

# Настройки
WINDOW_SECONDS = 60        # окно подсчёта запросов
MAX_REQUESTS = 120         # порог в окне
BAN_SECONDS = 5 * 60       # длительность бана

_attempts = defaultdict(list)   # ip -> [timestamps]
_banned_until = {}              # ip -> timestamp


def _client_ip():
    # Если приложение за доверенным прокси — включите ProxyFix (см. ниже) и
    # используйте request.remote_addr, он будет реальным IP клиента.
    return request.remote_addr or "unknown"


def register_ddos_guard(app):
    @app.before_request
    def _ddos_guard():
        ip = _client_ip()
        now = time.time()

        # 1. Проверка бана
        until = _banned_until.get(ip)
        if until:
            if until > now:
                abort(429)
            _banned_until.pop(ip, None)

        # 2. Скользящее окно
        attempts = _attempts[ip]
        # очищаем устаревшие
        while attempts and now - attempts[0] > WINDOW_SECONDS:
            attempts.pop(0)
        attempts.append(now)

        # 3. Превышение — бан
        if len(attempts) > MAX_REQUESTS:
            _banned_until[ip] = now + BAN_SECONDS
            _attempts.pop(ip, None)
            abort(429)