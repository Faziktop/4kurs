from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required

from . import db
from .models import Salon, Service, Specialist, Booking, User, ROLE_ADMIN, ROLE_MODERATOR, ROLE_CLIENT
from .decorators import roles_required

admin_bp = Blueprint("admin", __name__)


@admin_bp.before_request
@login_required
@roles_required(ROLE_ADMIN)
def guard():
    pass


@admin_bp.route("/")
def dashboard():
    salons_count = Salon.query.count()
    users_count = User.query.count()
    bookings_count = Booking.query.count()
    pending_count = Booking.query.filter_by(status="pending").count()
    salons = Salon.query.order_by(Salon.name).all()
    return render_template(
        "admin/dashboard.html",
        salons_count=salons_count,
        users_count=users_count,
        bookings_count=bookings_count,
        pending_count=pending_count,
        salons=salons,
    )


# ---------- Salons ----------

@admin_bp.route("/salons")
def salons():
    items = Salon.query.order_by(Salon.name).all()
    return render_template("admin/salons.html", salons=items)


@admin_bp.route("/salons/new", methods=["GET", "POST"])
def salon_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip()[:150]
        address = request.form.get("address", "").strip()[:255]
        phone = request.form.get("phone", "").strip()[:30]
        description = request.form.get("description", "").strip()[:2000]
        photo_url = request.form.get("photo_url", "").strip()[:300]
        if not name or not address:
            flash("Укажите название и адрес парикмахерской.", "danger")
        else:
            db.session.add(Salon(name=name, address=address, phone=phone,
                                  description=description, photo_url=photo_url))
            db.session.commit()
            flash("Парикмахерская добавлена.", "success")
            return redirect(url_for("admin.salons"))
    return render_template("admin/salon_form.html", salon=None)


@admin_bp.route("/salons/<int:salon_id>/edit", methods=["GET", "POST"])
def salon_edit(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    if request.method == "POST":
        salon.name = request.form.get("name", "").strip()[:150]
        salon.address = request.form.get("address", "").strip()[:255]
        salon.phone = request.form.get("phone", "").strip()[:30]
        salon.description = request.form.get("description", "").strip()[:2000]
        salon.photo_url = request.form.get("photo_url", "").strip()[:300]
        salon.is_active = bool(request.form.get("is_active"))
        db.session.commit()
        flash("Данные парикмахерской обновлены.", "success")
        return redirect(url_for("admin.salons"))
    return render_template("admin/salon_form.html", salon=salon)


@admin_bp.route("/salons/<int:salon_id>/delete", methods=["POST"])
def salon_delete(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    for mod in User.query.filter_by(salon_id=salon.id).all():
        mod.salon_id = None
        mod.role = ROLE_CLIENT
    db.session.delete(salon)
    db.session.commit()
    flash("Парикмахерская удалена.", "info")
    return redirect(url_for("admin.salons"))


# ---------- Users / moderators ----------

@admin_bp.route("/users")
def users():
    items = User.query.order_by(User.role, User.full_name).all()
    salons = Salon.query.filter_by(is_active=True).order_by(Salon.name).all()
    return render_template("admin/users.html", users=items, salons=salons)


@admin_bp.route("/users/<int:user_id>/assign_moderator", methods=["POST"])
def assign_moderator(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == ROLE_ADMIN:
        flash("Нельзя изменить роль администратора.", "danger")
        return redirect(url_for("admin.users"))
    salon_id = request.form.get("salon_id", type=int)
    salon = Salon.query.get(salon_id) if salon_id else None
    if not salon:
        flash("Выберите парикмахерскую для назначения модератором.", "danger")
        return redirect(url_for("admin.users"))
    user.role = ROLE_MODERATOR
    user.salon_id = salon.id
    db.session.commit()
    flash(f"{user.full_name} назначен(а) модератором «{salon.name}».", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/revoke_moderator", methods=["POST"])
def revoke_moderator(user_id):
    user = User.query.get_or_404(user_id)
    if user.role != ROLE_MODERATOR:
        abort(400)
    user.role = ROLE_CLIENT
    user.salon_id = None
    db.session.commit()
    flash(f"С пользователя {user.full_name} снята роль модератора.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/toggle_active", methods=["POST"])
def toggle_active(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == ROLE_ADMIN:
        flash("Нельзя заблокировать администратора.", "danger")
        return redirect(url_for("admin.users"))
    user.is_active_flag = not user.is_active_flag
    db.session.commit()
    flash("Статус учётной записи обновлён.", "success")
    return redirect(url_for("admin.users"))


# ---------- Cross-salon management ----------

@admin_bp.route("/salons/<int:salon_id>/services")
def salon_services(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    items = Service.query.filter_by(salon_id=salon.id).order_by(Service.name).all()
    return render_template("admin/salon_services.html", salon=salon, services=items)


@admin_bp.route("/salons/<int:salon_id>/specialists")
def salon_specialists(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    items = Specialist.query.filter_by(salon_id=salon.id).order_by(Specialist.full_name).all()
    return render_template("admin/salon_specialists.html", salon=salon, specialists=items)


@admin_bp.route("/salons/<int:salon_id>/bookings")
def salon_bookings(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    items = Booking.query.filter_by(salon_id=salon.id).order_by(Booking.booking_datetime.desc()).all()
    return render_template("admin/salon_bookings.html", salon=salon, bookings=items)