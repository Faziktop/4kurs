from datetime import datetime, timedelta, date

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from . import db, limiter
from .models import Salon, Service, Specialist, Booking, STATUS_PENDING, STATUS_CANCELLED

main_bp = Blueprint("main", __name__)

WORK_START_HOUR = 9
WORK_END_HOUR = 20
SLOT_STEP_MINUTES = 30


def generate_slots_for_date(day):
    slots = []
    current = datetime.combine(day, datetime.min.time()).replace(hour=WORK_START_HOUR)
    end = datetime.combine(day, datetime.min.time()).replace(hour=WORK_END_HOUR)
    while current < end:
        slots.append(current)
        current += timedelta(minutes=SLOT_STEP_MINUTES)
    return slots


@main_bp.route("/")
def index():
    salons = Salon.query.filter_by(is_active=True).order_by(Salon.name).all()
    return render_template("index.html", salons=salons)


@main_bp.route("/salon/<int:salon_id>")
def salon_detail(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    services = Service.query.filter_by(salon_id=salon.id, is_active=True).all()
    specialists = Specialist.query.filter_by(salon_id=salon.id, is_active=True).all()
    return render_template("salon_detail.html", salon=salon, services=services, specialists=specialists)


@main_bp.route("/salon/<int:salon_id>/book", methods=["GET", "POST"])
@login_required
@limiter.limit("20 per minute;100 per hour", methods=["POST"])
def book(salon_id):
    salon = Salon.query.get_or_404(salon_id)
    services = Service.query.filter_by(salon_id=salon.id, is_active=True).all()
    specialists = Specialist.query.filter_by(salon_id=salon.id, is_active=True).all()

    selected_service_id = request.values.get("service_id", type=int)
    selected_specialist_id = request.values.get("specialist_id", type=int)
    selected_date_str = request.values.get("date")
    try:
        selected_date = datetime.strptime(selected_date_str, "%Y-%m-%d").date() if selected_date_str else date.today()
    except ValueError:
        selected_date = date.today()
    if selected_date < date.today():
        selected_date = date.today()

    available_slots = []
    if selected_specialist_id:
        all_slots = generate_slots_for_date(selected_date)
        taken = {
            b.booking_datetime
            for b in Booking.query.filter_by(specialist_id=selected_specialist_id)
            .filter(Booking.status.in_(["pending", "confirmed"]))
            .all()
        }
        now = datetime.now()
        available_slots = [s for s in all_slots if s not in taken and s > now]

    if request.method == "POST":
        service_id = request.form.get("service_id", type=int)
        specialist_id = request.form.get("specialist_id", type=int)
        slot_str = request.form.get("slot")
        note = request.form.get("note", "").strip()[:500]

        service = Service.query.filter_by(id=service_id, salon_id=salon.id).first()
        specialist = Specialist.query.filter_by(id=specialist_id, salon_id=salon.id).first()

        error = None
        booking_dt = None
        if not service or not specialist:
            error = "Выберите услугу и специалиста."
        elif not slot_str:
            error = "Выберите время записи."
        else:
            try:
                booking_dt = datetime.strptime(slot_str, "%Y-%m-%dT%H:%M")
            except ValueError:
                error = "Некорректное время."

        if not error and booking_dt:
            clash = Booking.query.filter_by(
                specialist_id=specialist.id, booking_datetime=booking_dt
            ).filter(Booking.status.in_(["pending", "confirmed"])).first()
            if clash:
                error = "Это время уже занято, выберите другое."
            elif booking_dt < datetime.now():
                error = "Нельзя записаться на прошедшее время."

        if error:
            flash(error, "danger")
        else:
            new_booking = Booking(
                user_id=current_user.id,
                salon_id=salon.id,
                service_id=service.id,
                specialist_id=specialist.id,
                booking_datetime=booking_dt,
                status=STATUS_PENDING,
                note=note,
            )
            db.session.add(new_booking)
            db.session.commit()
            flash("Заявка на запись отправлена! Ожидайте подтверждения парикмахерской.", "success")
            return redirect(url_for("main.profile"))

    return render_template(
        "booking_form.html",
        salon=salon,
        services=services,
        specialists=specialists,
        selected_service_id=selected_service_id,
        selected_specialist_id=selected_specialist_id,
        selected_date=selected_date,
        available_slots=available_slots,
    )


@main_bp.route("/profile")
@login_required
def profile():
    bookings = (
        Booking.query.filter_by(user_id=current_user.id)
        .order_by(Booking.booking_datetime.desc())
        .all()
    )
    return render_template("profile.html", bookings=bookings)


@main_bp.route("/profile/edit", methods=["GET", "POST"])
@login_required
def edit_profile():
    if request.method == "POST":
        current_user.full_name = request.form.get("full_name", current_user.full_name).strip()[:150]
        current_user.phone = request.form.get("phone", current_user.phone).strip()[:30]
        new_password = request.form.get("password", "")
        if new_password:
            if len(new_password) < 6:
                flash("Пароль должен содержать не менее 6 символов.", "danger")
                return render_template("edit_profile.html")
            if len(new_password) > 200:
                flash("Слишком длинный пароль.", "danger")
                return render_template("edit_profile.html")
            current_user.set_password(new_password)
        db.session.commit()
        flash("Профиль обновлён.", "success")
        return redirect(url_for("main.profile"))
    return render_template("edit_profile.html")


@main_bp.route("/bookings/<int:booking_id>/cancel", methods=["POST"])
@login_required
@limiter.limit("10 per minute")
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        abort(403)
    if booking.status in ("pending", "confirmed"):
        booking.status = STATUS_CANCELLED
        db.session.commit()
        flash("Запись отменена.", "info")
    else:
        flash("Эту запись нельзя отменить.", "warning")
    return redirect(url_for("main.profile"))