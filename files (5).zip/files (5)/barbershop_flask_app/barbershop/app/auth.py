from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from . import db
from .models import User, ROLE_CLIENT

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        error = None
        if not full_name or not email or not password:
            error = "Заполните все обязательные поля."
        elif password != password2:
            error = "Пароли не совпадают."
        elif len(password) < 6:
            error = "Пароль должен содержать не менее 6 символов."
        elif User.query.filter_by(email=email).first():
            error = "Пользователь с таким e-mail уже зарегистрирован."

        if error:
            flash(error, "danger")
            return render_template("register.html", full_name=full_name, email=email, phone=phone)

        user = User(full_name=full_name, email=email, phone=phone, role=ROLE_CLIENT)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("Регистрация прошла успешно. Добро пожаловать!", "success")
        return redirect(url_for("main.index"))

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()

        if user is None or not user.check_password(password):
            flash("Неверный e-mail или пароль.", "danger")
            return render_template("login.html", email=email)

        if not user.is_active_flag:
            flash("Учётная запись заблокирована. Обратитесь к администратору.", "danger")
            return render_template("login.html", email=email)

        login_user(user)
        flash(f"Здравствуйте, {user.full_name}!", "success")

        next_page = request.args.get("next")
        if next_page:
            return redirect(next_page)
        if user.is_admin():
            return redirect(url_for("admin.dashboard"))
        if user.is_moderator():
            return redirect(url_for("moderator.dashboard"))
        return redirect(url_for("main.index"))

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("main.index"))
