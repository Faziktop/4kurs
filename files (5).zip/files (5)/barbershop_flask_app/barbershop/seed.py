"""
Скрипт наполнения базы данных тестовыми данными.
Запуск: python seed.py
Создаёт:
  - администратора (admin@barber.local / admin123)
  - две парикмахерские с услугами и специалистами
  - модератора для одной из парикмахерских (moderator@barber.local / moder123)
  - тестового клиента (client@barber.local / client123)
"""
from app import create_app, db
from app.models import User, Salon, Service, Specialist, ROLE_ADMIN, ROLE_MODERATOR, ROLE_CLIENT

app = create_app()

with app.app_context():
    db.drop_all()
    db.create_all()

    admin = User(full_name="Администратор сети", email="admin@barber.local", role=ROLE_ADMIN)
    admin.set_password("admin123")
    db.session.add(admin)

    salon1 = Salon(name="Барбершоп «На Тверской»", address="г. Москва, ул. Тверская, д. 10",
                    phone="+7 (495) 111-22-33",
                    description="Классический барбершоп в центре города: стрижки, бритьё, уход за бородой.")
    salon2 = Salon(name="Салон красоты «Стиль»", address="г. Москва, ул. Арбат, д. 5",
                    phone="+7 (495) 444-55-66",
                    description="Женские и мужские стрижки, окрашивание, укладки.")
    db.session.add_all([salon1, salon2])
    db.session.flush()

    services1 = [
        Service(salon_id=salon1.id, name="Мужская стрижка", description="Стрижка машинкой и ножницами",
                price=1200, duration_minutes=40),
        Service(salon_id=salon1.id, name="Стрижка бороды", description="Оформление и стрижка бороды",
                price=800, duration_minutes=30),
        Service(salon_id=salon1.id, name="Королевское бритьё", description="Бритьё опасной бритвой с горячим полотенцем",
                price=1000, duration_minutes=30),
    ]
    services2 = [
        Service(salon_id=salon2.id, name="Женская стрижка", description="Стрижка и укладка",
                price=2000, duration_minutes=60),
        Service(salon_id=salon2.id, name="Окрашивание", description="Однотонное окрашивание волос",
                price=3500, duration_minutes=120),
        Service(salon_id=salon2.id, name="Укладка", description="Укладка феном и стайлером",
                price=1200, duration_minutes=40),
    ]
    db.session.add_all(services1 + services2)

    specialists1 = [
        Specialist(salon_id=salon1.id, full_name="Игорь Соколов", specialization="Барбер",
                   description="Опыт работы 7 лет, специализация — классические и фейд-стрижки."),
        Specialist(salon_id=salon1.id, full_name="Максим Петров", specialization="Барбер, бритьё",
                   description="Мастер по бритью опасной бритвой и оформлению бороды."),
    ]
    specialists2 = [
        Specialist(salon_id=salon2.id, full_name="Анна Кузнецова", specialization="Стилист-колорист",
                   description="Специалист по сложному окрашиванию и стрижкам."),
        Specialist(salon_id=salon2.id, full_name="Елена Смирнова", specialization="Стилист",
                   description="Женские и мужские стрижки, укладки на любой случай."),
    ]
    db.session.add_all(specialists1 + specialists2)

    moderator = User(full_name="Модератор Барбершопа", email="moderator@barber.local",
                      role=ROLE_MODERATOR, salon_id=salon1.id)
    moderator.set_password("moder123")
    db.session.add(moderator)

    client = User(full_name="Тестовый Клиент", email="client@barber.local",
                   phone="+7 900 000-00-00", role=ROLE_CLIENT)
    client.set_password("client123")
    db.session.add(client)

    db.session.commit()

    print("База данных наполнена тестовыми данными.")
    print("Администратор:  admin@barber.local / admin123")
    print("Модератор:      moderator@barber.local / moder123  (парикмахерская: «Барбершоп «На Тверской»)")
    print("Клиент:         client@barber.local / client123")
