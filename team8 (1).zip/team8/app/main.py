from flask import Blueprint, render_template, session, abort
from markupsafe import Markup, escape
from sqlalchemy import or_
from sqlalchemy.orm import joinedload

from .extensions import db
from .models import User, Channel, ChannelMember, Chat, Message

bp = Blueprint('main', __name__)


def _safe_escaped_display(value: str) -> Markup:
    """Renders text with HTML entities escaped exactly once (so <script> is &lt;script&gt;)."""
    if not value:
        return Markup('')
    raw = value.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
    return escape(raw)


@bp.app_template_filter('safe_escape')
def safe_escape_filter(value):
    return _safe_escaped_display(value)


@bp.get('/')
def index():
    user_id = session.get('user_id')
    current_user = db.session.get(User, user_id) if user_id else None
    recent_messages = []
    user_chats = []
    user_channels = []

    if current_user:
        user_chats = (
            Chat.query.filter(
                or_(Chat.user1_id == current_user.id, Chat.user2_id == current_user.id)
            )
            .order_by(Chat.id.asc())
            .all()
        )
        member_channel_ids = [
            cm.channel_id
            for cm in ChannelMember.query.filter_by(user_id=current_user.id).all()
        ]
        if member_channel_ids:
            user_channels = (
                Channel.query.filter(Channel.id.in_(member_channel_ids))
                .order_by(Channel.id.asc())
                .all()
            )

        access_filters = []
        chat_ids = [c.id for c in user_chats]
        if chat_ids:
            access_filters.append(Message.chat_id.in_(chat_ids))
        if member_channel_ids:
            access_filters.append(Message.channel_id.in_(member_channel_ids))

        if access_filters:
            recent_messages = (
                Message.query.options(joinedload(Message.user))
                .filter(or_(*access_filters))
                .order_by(Message.id.desc())
                .limit(50)
                .all()
            )

    return render_template(
        'index.html',
        current_user=current_user,
        chats=user_chats,
        channels=user_channels,
        messages=recent_messages,
    )


@bp.get('/u/<username>')
def user_profile(username: str):
    user = User.query.filter_by(username=username).first()
    if not user:
        abort(404)

    member_channel_ids = [
        cm.channel_id for cm in ChannelMember.query.filter_by(user_id=user.id).all()
    ]
    channels = (
        Channel.query.filter(Channel.id.in_(member_channel_ids))
        .order_by(Channel.id.asc())
        .all()
        if member_channel_ids
        else []
    )
    return render_template('profile.html', profile_user=user, channels=channels)


@bp.get('/chats/<int:chat_id>')
@bp.get('/chat/<int:chat_id>')
def view_chat(chat_id: int):
    user_id = session.get('user_id')
    if not user_id:
        abort(401)
    chat = db.session.get(Chat, chat_id)
    if not chat:
        abort(404)
    if user_id not in (chat.user1_id, chat.user2_id):
        abort(403)

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(chat_id=chat.id)
        .order_by(Message.id.asc())
        .all()
    )
    return render_template('chat.html', chat=chat, messages=messages)


@bp.get('/channels/<int:channel_id>')
@bp.get('/channel/<int:channel_id>')
def view_channel(channel_id: int):
    user_id = session.get('user_id')
    if not user_id:
        abort(401)
    channel = db.session.get(Channel, channel_id)
    if not channel:
        abort(404)

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(channel_id=channel.id)
        .order_by(Message.id.asc())
        .all()
    )
    return render_template('channel.html', channel=channel, messages=messages)