import html
import json
from functools import wraps
from flask import Blueprint, jsonify, current_app, request, session, Response
from sqlalchemy import or_
from sqlalchemy.orm import joinedload

from .extensions import db
from .models import User, Channel, ChannelMember, Chat, Message

bp = Blueprint('api', __name__)


def _sanitize_html_tags(value: str) -> str:
    """Escapes HTML tags like <script> into &lt;script&gt; while leaving plain text untouched."""
    if '<' in value or '>' in value:
        return html.escape(value, quote=False)
    return value


def get_current_user():
    user_id = session.get('user_id')
    if not user_id:
        return None
    return db.session.get(User, user_id)


def login_required_api(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if user is None:
            return jsonify({'error': 'Unauthorized'}), 401
        return fn(user, *args, **kwargs)
    return wrapper


def _get_payload():
    data = request.get_json(silent=True)
    if isinstance(data, dict):
        return data
    if request.form:
        return request.form.to_dict()
    return {}


def _serialize_channel(channel: Channel):
    return {
        'id': channel.id,
        'channel_id': channel.id,
        'name': channel.name,
        'created_by': channel.created_by,
        'created_at': channel.created_at.isoformat() if channel.created_at else None,
    }


def _serialize_chat(chat: Chat, current_user_id: int, users_map=None):
    other_id = chat.user2_id if chat.user1_id == current_user_id else chat.user1_id
    if users_map is not None:
        u1 = users_map.get(chat.user1_id)
        u2 = users_map.get(chat.user2_id)
        other = users_map.get(other_id)
    else:
        u1 = db.session.get(User, chat.user1_id)
        u2 = db.session.get(User, chat.user2_id)
        other = db.session.get(User, other_id)

    other_username = other.username if other else ''
    usernames = [u.username for u in (u1, u2) if u is not None]
    return {
        'id': chat.id,
        'chat_id': chat.id,
        'user1_id': chat.user1_id,
        'user2_id': chat.user2_id,
        'username': other_username,
        'partner': other_username,
        'users': usernames,
        'member_ids': [chat.user1_id, chat.user2_id],
        'created_at': chat.created_at.isoformat() if chat.created_at else None,
    }


def _serialize_message(msg: Message):
    uname = msg.user.username if msg.user else ''
    return {
        'id': msg.id,
        'message_id': msg.id,
        'chat_id': msg.chat_id,
        'channel_id': msg.channel_id,
        'user_id': msg.user_id,
        'sender_id': msg.user_id,
        'username': uname,
        'author': uname,
        'text': msg.text,
        'created_at': msg.created_at.isoformat() if msg.created_at else None,
    }


@bp.get('/health')
def health():
    return jsonify({
        'status': 'ok',
        'team_id': current_app.config['TEAM_ID'],
        'team_name': current_app.config['TEAM_NAME'],
    })


# --- 2. Публичные каналы ---

@bp.post('/channels')
@login_required_api
def create_channel(current_user: User):
    data = _get_payload()
    name = data.get('name')
    if not isinstance(name, str) or not name.strip():
        return jsonify({'error': 'Channel name is required'}), 400
    name = _sanitize_html_tags(name.strip())[:120]

    channel = Channel(name=name, created_by=current_user.id)
    db.session.add(channel)
    db.session.flush()

    membership = ChannelMember(channel_id=channel.id, user_id=current_user.id)
    db.session.add(membership)
    db.session.commit()

    return jsonify(_serialize_channel(channel)), 201


@bp.get('/channels')
@login_required_api
def list_channels(current_user: User):
    channels = Channel.query.order_by(Channel.id.asc()).all()
    return jsonify([_serialize_channel(c) for c in channels]), 200


@bp.get('/channels/<int:channel_id>')
@login_required_api
def get_channel(current_user: User, channel_id: int):
    channel = db.session.get(Channel, channel_id)
    if not channel:
        return jsonify({'error': 'Channel not found'}), 404
    return jsonify(_serialize_channel(channel)), 200


@bp.post('/channels/<int:channel_id>/join')
@login_required_api
def join_channel(current_user: User, channel_id: int):
    channel = db.session.get(Channel, channel_id)
    if not channel:
        return jsonify({'error': 'Channel not found'}), 404

    existing = ChannelMember.query.filter_by(
        channel_id=channel.id, user_id=current_user.id
    ).first()
    if not existing:
        db.session.add(ChannelMember(channel_id=channel.id, user_id=current_user.id))
        db.session.commit()

    res = _serialize_channel(channel)
    res['status'] = 'joined'
    res['user_id'] = current_user.id
    return jsonify(res), 200


# --- 3. Приватные чаты (1-на-1) ---

@bp.post('/chats')
@login_required_api
def create_chat(current_user: User):
    data = _get_payload()
    target_username = data.get('username')
    if not isinstance(target_username, str) or not target_username.strip():
        return jsonify({'error': 'username is required'}), 400

    target_username = target_username.strip()
    target_user = User.query.filter_by(username=target_username).first()
    if not target_user:
        return jsonify({'error': 'User not found'}), 404

    u1_id = min(current_user.id, target_user.id)
    u2_id = max(current_user.id, target_user.id)

    chat = Chat.query.filter_by(user1_id=u1_id, user2_id=u2_id).first()
    if chat:
        users_map = {current_user.id: current_user, target_user.id: target_user}
        return jsonify(_serialize_chat(chat, current_user.id, users_map)), 200

    chat = Chat(user1_id=u1_id, user2_id=u2_id)
    db.session.add(chat)
    db.session.commit()

    users_map = {current_user.id: current_user, target_user.id: target_user}
    return jsonify(_serialize_chat(chat, current_user.id, users_map)), 201


@bp.get('/chats')
@login_required_api
def list_chats(current_user: User):
    chats = (
        Chat.query.filter(
            or_(Chat.user1_id == current_user.id, Chat.user2_id == current_user.id)
        )
        .order_by(Chat.id.asc())
        .all()
    )
    user_ids = set()
    for c in chats:
        user_ids.add(c.user1_id)
        user_ids.add(c.user2_id)
    users_map = (
        {u.id: u for u in User.query.filter(User.id.in_(user_ids)).all()}
        if user_ids
        else {}
    )
    return jsonify([_serialize_chat(c, current_user.id, users_map) for c in chats]), 200


@bp.get('/chats/<int:chat_id>')
@login_required_api
def get_chat(current_user: User, chat_id: int):
    chat = db.session.get(Chat, chat_id)
    if not chat:
        return jsonify({'error': 'Chat not found'}), 404
    if current_user.id not in (chat.user1_id, chat.user2_id):
        return jsonify({'error': 'Forbidden'}), 403
    return jsonify(_serialize_chat(chat, current_user.id)), 200


# --- 4. Отправка сообщения ---

def _create_message_for_target(current_user: User, chat_id, channel_id, raw_text):
    if not isinstance(raw_text, str) or not raw_text.strip():
        return jsonify({'error': 'Message text is required'}), 400

    if (chat_id is None and channel_id is None) or (
        chat_id is not None and channel_id is not None
    ):
        return jsonify({'error': 'Specify either chat_id or channel_id'}), 400

    clean_text = _sanitize_html_tags(raw_text)

    if chat_id is not None:
        try:
            chat_id = int(chat_id)
        except (ValueError, TypeError):
            return jsonify({'error': 'Invalid chat_id'}), 400

        chat = db.session.get(Chat, chat_id)
        if not chat:
            return jsonify({'error': 'Chat not found'}), 404

        if current_user.id not in (chat.user1_id, chat.user2_id):
            return jsonify({'error': 'Forbidden: not a chat participant'}), 403

        msg = Message(chat_id=chat.id, user_id=current_user.id, text=clean_text)
        db.session.add(msg)
        db.session.commit()
        return jsonify(_serialize_message(msg)), 201

    try:
        channel_id = int(channel_id)
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid channel_id'}), 400

    channel = db.session.get(Channel, channel_id)
    if not channel:
        return jsonify({'error': 'Channel not found'}), 404

    is_member = (
        channel.created_by == current_user.id
        or ChannelMember.query.filter_by(
            channel_id=channel.id, user_id=current_user.id
        ).first()
        is not None
    )
    if not is_member:
        return jsonify({'error': 'Forbidden: not a channel member'}), 403

    msg = Message(channel_id=channel.id, user_id=current_user.id, text=clean_text)
    db.session.add(msg)
    db.session.commit()
    return jsonify(_serialize_message(msg)), 201


@bp.post('/messages')
@login_required_api
def send_message(current_user: User):
    data = _get_payload()
    return _create_message_for_target(
        current_user,
        data.get('chat_id'),
        data.get('channel_id'),
        data.get('text'),
    )


# --- 5. История сообщений ---

@bp.get('/chats/<int:chat_id>/messages')
@login_required_api
def get_chat_messages(current_user: User, chat_id: int):
    chat = db.session.get(Chat, chat_id)
    if not chat:
        return jsonify({'error': 'Chat not found'}), 404
    if current_user.id not in (chat.user1_id, chat.user2_id):
        return jsonify({'error': 'Forbidden'}), 403

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(chat_id=chat.id)
        .order_by(Message.id.asc())
        .all()
    )
    return jsonify([_serialize_message(m) for m in messages]), 200


@bp.post('/chats/<int:chat_id>/messages')
@login_required_api
def post_chat_message(current_user: User, chat_id: int):
    data = _get_payload()
    return _create_message_for_target(current_user, chat_id, None, data.get('text'))


@bp.get('/channels/<int:channel_id>/messages')
@login_required_api
def get_channel_messages(current_user: User, channel_id: int):
    channel = db.session.get(Channel, channel_id)
    if not channel:
        return jsonify({'error': 'Channel not found'}), 404

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(channel_id=channel.id)
        .order_by(Message.id.asc())
        .all()
    )
    return jsonify([_serialize_message(m) for m in messages]), 200


@bp.post('/channels/<int:channel_id>/messages')
@login_required_api
def post_channel_message(current_user: User, channel_id: int):
    data = _get_payload()
    return _create_message_for_target(current_user, None, channel_id, data.get('text'))


# --- 6. Поиск по сообщениям ---

@bp.get('/messages/search')
@login_required_api
def search_messages(current_user: User):
    q = request.args.get('q', '')
    if not isinstance(q, str) or not q.strip():
        return jsonify([]), 200

    q_clean = q.strip()
    if len(q_clean) > 500:
        return jsonify({'error': 'Query too long'}), 400

    user_chat_ids = [
        c.id
        for c in Chat.query.filter(
            or_(Chat.user1_id == current_user.id, Chat.user2_id == current_user.id)
        ).all()
    ]
    user_channel_ids = [
        cm.channel_id
        for cm in ChannelMember.query.filter_by(user_id=current_user.id).all()
    ]

    access_filters = []
    if user_chat_ids:
        access_filters.append(Message.chat_id.in_(user_chat_ids))
    if user_channel_ids:
        access_filters.append(Message.channel_id.in_(user_channel_ids))

    if not access_filters:
        return jsonify([]), 200

    candidate_messages = (
        Message.query.options(joinedload(Message.user))
        .filter(or_(*access_filters))
        .order_by(Message.id.asc())
        .all()
    )

    q_lower = q_clean.lower()
    matched = [
        _serialize_message(m)
        for m in candidate_messages
        if q_lower in (m.text or '').lower()
    ]
    return jsonify(matched), 200


# --- 7. Публичный профиль (API) ---

@bp.route('/profile', methods=['GET', 'POST', 'PUT'])
@login_required_api
def update_profile(current_user: User):
    if request.method in ('POST', 'PUT'):
        data = _get_payload()
        bio = data.get('bio')
        if bio is None or not isinstance(bio, str):
            return jsonify({'error': 'bio must be a string'}), 400
        current_user.bio = _sanitize_html_tags(bio.strip())[:2000]
        db.session.commit()

    member_channel_ids = [
        cm.channel_id
        for cm in ChannelMember.query.filter_by(user_id=current_user.id).all()
    ]
    channels = (
        Channel.query.filter(Channel.id.in_(member_channel_ids))
        .order_by(Channel.id.asc())
        .all()
        if member_channel_ids
        else []
    )
    return jsonify({
        'id': current_user.id,
        'user_id': current_user.id,
        'username': current_user.username,
        'bio': current_user.bio or '',
        'channels': [_serialize_channel(c) for c in channels],
    }), 200


# --- 8. Экспорт истории чата / канала ---

ALLOWED_EXPORT_FORMATS = {'txt', 'json'}


def _validate_export_format(fmt: str) -> bool:
    if not fmt or not isinstance(fmt, str):
        return False
    if fmt not in ALLOWED_EXPORT_FORMATS:
        return False
    return True


def _build_export_response(messages, filename_prefix: str, entity_id: int, fmt: str):
    safe_filename = f'{filename_prefix}_{int(entity_id)}.{fmt}'
    if fmt == 'json':
        payload = json.dumps(
            [_serialize_message(m) for m in messages], ensure_ascii=False, indent=2
        )
        mimetype = 'application/json; charset=utf-8'
    else:
        lines = []
        for m in messages:
            ts = m.created_at.isoformat() if m.created_at else ''
            uname = m.user.username if m.user else f'user_{m.user_id}'
            lines.append(f'[{ts}] {uname}: {m.text}')
        payload = '\n'.join(lines) + ('\n' if lines else '')
        mimetype = 'text/plain; charset=utf-8'

    return Response(
        payload,
        status=200,
        mimetype=mimetype,
        headers={
            'Content-Disposition': f'attachment; filename="{safe_filename}"',
        },
    )


@bp.get('/chats/<int:chat_id>/export')
@login_required_api
def export_chat(current_user: User, chat_id: int):
    fmt = request.args.get('format', 'txt')
    if not _validate_export_format(fmt):
        return jsonify({'error': 'Invalid export format'}), 400

    chat = db.session.get(Chat, chat_id)
    if not chat:
        return jsonify({'error': 'Chat not found'}), 404
    if current_user.id not in (chat.user1_id, chat.user2_id):
        return jsonify({'error': 'Forbidden'}), 403

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(chat_id=chat.id)
        .order_by(Message.id.asc())
        .all()
    )
    return _build_export_response(messages, 'chat', chat.id, fmt)


@bp.get('/channels/<int:channel_id>/export')
@login_required_api
def export_channel(current_user: User, channel_id: int):
    fmt = request.args.get('format', 'txt')
    if not _validate_export_format(fmt):
        return jsonify({'error': 'Invalid export format'}), 400

    channel = db.session.get(Channel, channel_id)
    if not channel:
        return jsonify({'error': 'Channel not found'}), 404

    messages = (
        Message.query.options(joinedload(Message.user))
        .filter_by(channel_id=channel.id)
        .order_by(Message.id.asc())
        .all()
    )
    return _build_export_response(messages, 'channel', channel.id, fmt)