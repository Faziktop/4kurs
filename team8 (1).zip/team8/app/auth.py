import time
import threading
from collections import defaultdict
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)

_login_lock = threading.Lock()
_failed_by_user = defaultdict(list)
_failed_by_ip = defaultdict(list)

WINDOW_SECONDS = 60.0
MAX_USER_FAILURES = 5
MAX_IP_FAILURES = 15


def _extract_credentials():
    data = request.get_json(silent=True) if request.is_json else None
    source = data if isinstance(data, dict) else request.form
    username = (source.get('username') or '').strip()
    password = source.get('password') or ''
    return username, password


def _prune(timestamps, now):
    cutoff = now - WINDOW_SECONDS
    while timestamps and timestamps[0] < cutoff:
        timestamps.pop(0)


def _is_user_rate_limited(username):
    now = time.monotonic()
    with _login_lock:
        user_key = username or '__empty__'
        _prune(_failed_by_user[user_key], now)
        if len(_failed_by_user[user_key]) >= MAX_USER_FAILURES:
            return True
    return False


def _record_failed_login(username, ip_addr):
    now = time.monotonic()
    with _login_lock:
        user_key = username or '__empty__'
        _prune(_failed_by_user[user_key], now)
        _failed_by_user[user_key].append(now)

        ip_key = ip_addr or 'unknown'
        _prune(_failed_by_ip[ip_key], now)
        _failed_by_ip[ip_key].append(now)

        return (
            len(_failed_by_user[user_key]) >= MAX_USER_FAILURES
            or len(_failed_by_ip[ip_key]) >= MAX_IP_FAILURES
        )


def _clear_user_failures(username):
    with _login_lock:
        _failed_by_user.pop(username or '__empty__', None)


def _rate_limit_response():
    if request.is_json:
        resp = jsonify({'error': 'Too many login attempts. Please try again later.'})
    else:
        resp = jsonify({'error': 'Слишком много попыток входа. Попробуйте позже.'})
    resp.status_code = 429
    resp.headers['Retry-After'] = '60'
    return resp


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username, password = _extract_credentials()
        if not username or not password:
            if request.is_json:
                return jsonify({'error': 'Заполните все поля'}), 400
            flash('Заполните все поля')
        elif len(username) > 80:
            if request.is_json:
                return jsonify({'error': 'Слишком длинный логин'}), 400
            flash('Слишком длинный логин')
        elif User.query.filter_by(username=username).first():
            if request.is_json:
                return jsonify({'error': 'Пользователь уже существует'}), 400
            flash('Пользователь уже существует')
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            session['user_id'] = user.id
            if request.is_json:
                return jsonify({
                    'id': user.id,
                    'user_id': user.id,
                    'username': user.username,
                }), 201
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username, password = _extract_credentials()
        ip_addr = request.remote_addr or '127.0.0.1'

        if _is_user_rate_limited(username):
            return _rate_limit_response()

        user = User.query.filter_by(username=username).first() if username else None
        if user and user.check_password(password):
            _clear_user_failures(username)
            session['user_id'] = user.id
            if request.is_json:
                return jsonify({
                    'status': 'ok',
                    'id': user.id,
                    'user_id': user.id,
                    'username': user.username,
                }), 200
            return redirect(url_for('main.index'))

        should_throttle = _record_failed_login(username, ip_addr)
        if should_throttle:
            return _rate_limit_response()

        if request.is_json:
            return jsonify({'error': 'Неверные данные'}), 401
        flash('Неверные данные')
    return render_template('auth/login.html')


@bp.get('/logout')
def logout():
    session.pop('user_id', None)
    if request.is_json:
        return jsonify({'status': 'ok'}), 200
    return redirect(url_for('main.index'))