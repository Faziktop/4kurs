"""
Информационная система учета техники в техникуме.
Python 3 + SQLite + Tkinter. Запуск: python tech_accounting.py
"""
import sqlite3
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    class _Stub:
        def __getattr__(self, name): return _Stub
        def __call__(self, *a, **kw): return _Stub()
    tk = ttk = messagebox = _Stub()
from datetime import date

DB_NAME = "tech_accounting.db"

# ==================== ПАЛИТРА И СТИЛЬ ====================
COLORS = {
    "primary":     "#2563eb",
    "primary_h":   "#1d4ed8",
    "success":     "#16a34a",
    "success_h":   "#15803d",
    "danger":      "#dc2626",
    "danger_h":    "#b91c1c",
    "warning":     "#f59e0b",
    "bg":          "#f1f5f9",
    "card":        "#ffffff",
    "header":      "#1e293b",
    "header_text": "#f8fafc",
    "text":        "#0f172a",
    "muted":       "#64748b",
    "border":      "#e2e8f0",
    "stripe":      "#f8fafc",
}
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 16, "bold")
FONT_H1 = ("Segoe UI", 13, "bold")


def apply_style(root):
    st = ttk.Style(root)
    st.theme_use("clam")

    st.configure(".", font=FONT, background=COLORS["bg"], foreground=COLORS["text"])

    # Notebook
    st.configure("TNotebook", background=COLORS["bg"], borderwidth=0, tabmargins=[2, 8, 2, 0])
    st.configure("TNotebook.Tab", padding=[18, 8], font=FONT_BOLD,
                 background=COLORS["card"], foreground=COLORS["muted"], borderwidth=0)
    st.map("TNotebook.Tab",
           background=[("selected", COLORS["card"])],
           foreground=[("selected", COLORS["primary"])],
           expand=[("selected", [1, 1, 1, 0])])

    # Frame
    st.configure("TFrame", background=COLORS["bg"])
    st.configure("Card.TFrame", background=COLORS["card"], relief="flat")
    st.configure("Header.TFrame", background=COLORS["header"])
    st.configure("Status.TFrame", background=COLORS["header"])

    # Label
    st.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=FONT)
    st.configure("Card.TLabel", background=COLORS["card"], foreground=COLORS["text"])
    st.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"])
    st.configure("Header.TLabel", background=COLORS["header"],
                 foreground=COLORS["header_text"], font=FONT_TITLE)
    st.configure("HeaderSub.TLabel", background=COLORS["header"],
                 foreground="#cbd5e1", font=FONT)
    st.configure("Status.TLabel", background=COLORS["header"],
                 foreground="#cbd5e1", font=("Segoe UI", 9))
    st.configure("H1.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=FONT_H1)

    # Entry
    st.configure("TEntry", padding=6, fieldbackground="white",
                 bordercolor=COLORS["border"], lightcolor=COLORS["border"],
                 darkcolor=COLORS["border"])
    st.map("TEntry", bordercolor=[("focus", COLORS["primary"])])

    # Combobox
    st.configure("TCombobox", padding=6, fieldbackground="white",
                 bordercolor=COLORS["border"], lightcolor=COLORS["border"],
                 darkcolor=COLORS["border"], arrowsize=14)
    st.map("TCombobox", fieldbackground=[("readonly", "white")],
           bordercolor=[("focus", COLORS["primary"])])

    # Buttons — по умолчанию нейтральные
    st.configure("TButton", padding=[14, 6], font=FONT_BOLD,
                 background=COLORS["card"], foreground=COLORS["text"],
                 borderwidth=1, bordercolor=COLORS["border"],
                 lightcolor=COLORS["card"], darkcolor=COLORS["card"])
    st.map("TButton",
           background=[("active", "#e2e8f0")],
           bordercolor=[("active", COLORS["muted"])])

    # Primary
    st.configure("Primary.TButton", background=COLORS["primary"], foreground="white",
                 bordercolor=COLORS["primary"], lightcolor=COLORS["primary"],
                 darkcolor=COLORS["primary"])
    st.map("Primary.TButton",
           background=[("active", COLORS["primary_h"])],
           bordercolor=[("active", COLORS["primary_h"])])

    # Success
    st.configure("Success.TButton", background=COLORS["success"], foreground="white",
                 bordercolor=COLORS["success"], lightcolor=COLORS["success"],
                 darkcolor=COLORS["success"])
    st.map("Success.TButton",
           background=[("active", COLORS["success_h"])],
           bordercolor=[("active", COLORS["success_h"])])

    # Danger
    st.configure("Danger.TButton", background=COLORS["danger"], foreground="white",
                 bordercolor=COLORS["danger"], lightcolor=COLORS["danger"],
                 darkcolor=COLORS["danger"])
    st.map("Danger.TButton",
           background=[("active", COLORS["danger_h"])],
           bordercolor=[("active", COLORS["danger_h"])])

    # Treeview
    st.configure("Treeview", background=COLORS["card"], fieldbackground=COLORS["card"],
                 foreground=COLORS["text"], rowheight=28, font=FONT, borderwidth=0)
    st.configure("Treeview.Heading", background="#e2e8f0", foreground=COLORS["text"],
                 font=FONT_BOLD, padding=[8, 6], relief="flat", borderwidth=0)
    st.map("Treeview.Heading", background=[("active", "#cbd5e1")])
    st.map("Treeview", background=[("selected", COLORS["primary"])],
           foreground=[("selected", "white")])

    # Scrollbar
    st.configure("Vertical.TScrollbar", background=COLORS["border"],
                 troughcolor=COLORS["bg"], borderwidth=0, arrowsize=12)


def card(parent):
    """Обёртка с эффектом карточки."""
    outer = ttk.Frame(parent, style="Card.TFrame")
    inner = ttk.Frame(outer, style="Card.TFrame", padding=16)
    inner.pack(fill="both", expand=True)
    return outer, inner


# ==================== БАЗА ДАННЫХ ====================
def connect():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = connect()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS Аудитории (
        КодАудитории INTEGER PRIMARY KEY AUTOINCREMENT,
        НомерАудитории TEXT NOT NULL UNIQUE,
        Корпус TEXT, Этаж INTEGER, Примечание TEXT);
    CREATE TABLE IF NOT EXISTS Сотрудники (
        КодСотрудника INTEGER PRIMARY KEY AUTOINCREMENT,
        Фамилия TEXT NOT NULL, Имя TEXT NOT NULL, Отчество TEXT,
        Должность TEXT, Телефон TEXT);
    CREATE TABLE IF NOT EXISTS Техника (
        КодТехники INTEGER PRIMARY KEY AUTOINCREMENT,
        ИнвентарныйНомер TEXT NOT NULL UNIQUE,
        Наименование TEXT NOT NULL, Модель TEXT, СерийныйНомер TEXT,
        ДатаПоступления TEXT, ГарантияДо TEXT, Стоимость REAL,
        Состояние TEXT, КодАудитории INTEGER, КодСотрудника INTEGER,
        Примечание TEXT,
        FOREIGN KEY (КодАудитории) REFERENCES Аудитории(КодАудитории),
        FOREIGN KEY (КодСотрудника) REFERENCES Сотрудники(КодСотрудника));
    CREATE TABLE IF NOT EXISTS Перемещения (
        КодПеремещения INTEGER PRIMARY KEY AUTOINCREMENT,
        КодТехники INTEGER NOT NULL,
        КодАудиторииОткуда INTEGER, КодАудиторииКуда INTEGER,
        ДатаПеремещения TEXT, КодСотрудника INTEGER, Основание TEXT,
        FOREIGN KEY (КодТехники) REFERENCES Техника(КодТехники),
        FOREIGN KEY (КодАудиторииОткуда) REFERENCES Аудитории(КодАудитории),
        FOREIGN KEY (КодАудиторииКуда) REFERENCES Аудитории(КодАудитории),
        FOREIGN KEY (КодСотрудника) REFERENCES Сотрудники(КодСотрудника));
    CREATE TABLE IF NOT EXISTS Ремонты (
        КодРемонта INTEGER PRIMARY KEY AUTOINCREMENT,
        КодТехники INTEGER NOT NULL,
        ДатаНачала TEXT, ДатаОкончания TEXT,
        ОписаниеНеисправности TEXT, СтоимостьРемонта REAL, Статус TEXT,
        FOREIGN KEY (КодТехники) REFERENCES Техника(КодТехники));
    """)
    cur = conn.cursor()
    if cur.execute("SELECT COUNT(*) FROM Аудитории").fetchone()[0] == 0:
        cur.executemany("INSERT INTO Аудитории (НомерАудитории,Корпус,Этаж) VALUES (?,?,?)",
            [("101","Основной",1),("201","Основной",2),("305","Лабораторный",3),
             ("306","Лабораторный",3),("Склад","—",1)])
        cur.executemany("INSERT INTO Сотрудники (Фамилия,Имя,Отчество,Должность) VALUES (?,?,?,?)",
            [("Иванов","Пётр","Сергеевич","Заведующий лабораторией"),
             ("Петрова","Анна","Викторовна","Преподаватель"),
             ("Сидоров","Максим","Олегович","Системный администратор")])
        cur.executemany(
            "INSERT INTO Техника (ИнвентарныйНомер,Наименование,Модель,Состояние,КодАудитории,КодСотрудника) VALUES (?,?,?,?,?,?)",
            [("ИНВ-001","Компьютер","HP ProDesk 400 G7","В работе",2,1),
             ("ИНВ-002","Компьютер","HP ProDesk 400 G7","В работе",2,1),
             ("ИНВ-003","Проектор","Epson EB-X41","В работе",2,2),
             ("ИНВ-004","Принтер","Canon i-SENSYS","В ремонте",3,3),
             ("ИНВ-005","Компьютер","Lenovo ThinkCentre","В работе",3,3),
             ("ИНВ-006","Интерактивная доска","Smart Board MX","В работе",3,2),
             ("ИНВ-007","Проектор","BenQ MS527","На складе",5,1),
             ("ИНВ-008","Принтер","HP LaserJet P1102","В работе",1,2),
             ("ИНВ-009","Ноутбук","Asus VivoBook 15","В работе",4,3),
             ("ИНВ-010","Компьютер","Aquarius Pro P30","Списано",5,1)])
        cur.execute("INSERT INTO Ремонты (КодТехники,ДатаНачала,ОписаниеНеисправности,Статус) VALUES (4,date('now','-3 days'),'Не включается','В процессе')")
        conn.commit()
    conn.close()


# ==================== ВСПОМОГАТЕЛЬНЫЕ ЭЛЕМЕНТЫ ФОРМ ====================
def field_row(parent, label, var, kind="entry", values=None):
    """Красивая строка формы: подпись + поле."""
    row = ttk.Frame(parent, style="Card.TFrame")
    row.pack(fill="x", pady=5)
    ttk.Label(row, text=label, style="Card.TLabel", width=22).pack(side="left")
    if kind == "combo":
        w = ttk.Combobox(row, textvariable=var, values=values, state="readonly")
    else:
        w = ttk.Entry(row, textvariable=var)
    w.pack(side="left", fill="x", expand=True, ipady=2)
    return w


def dialog_header(parent, title, subtitle=""):
    """Шапка диалога."""
    head = tk.Frame(parent, bg=COLORS["header"], height=64)
    head.pack(fill="x")
    head.pack_propagate(False)
    tk.Label(head, text=title, bg=COLORS["header"], fg=COLORS["header_text"],
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=16, pady=(10, 0))
    if subtitle:
        tk.Label(head, text=subtitle, bg=COLORS["header"], fg="#cbd5e1",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16)


def dialog_buttons(parent, on_save, on_cancel):
    bar = tk.Frame(parent, bg=COLORS["card"])
    bar.pack(fill="x", side="bottom", pady=12)
    ttk.Button(bar, text="Отмена", command=on_cancel).pack(side="right", padx=(6, 16))
    ttk.Button(bar, text="💾  Сохранить", style="Success.TButton",
               command=on_save).pack(side="right")


# ==================== ДИАЛОГ: ТЕХНИКА ====================
class TechDialog(tk.Toplevel):
    def __init__(self, parent, tech_id, on_save):
        super().__init__(parent)
        self.title("Техника")
        self.geometry("540x640")
        self.configure(bg=COLORS["card"])
        self.tech_id, self.on_save = tech_id, on_save

        conn = connect()
        self.rooms = conn.execute(
            "SELECT КодАудитории, НомерАудитории||COALESCE(' ('||Корпус||')','') FROM Аудитории ORDER BY НомерАудитории").fetchall()
        self.emps = conn.execute(
            "SELECT КодСотрудника, Фамилия||' '||Имя FROM Сотрудники ORDER BY Фамилия").fetchall()
        row = conn.execute("SELECT * FROM Техника WHERE КодТехники=?", (tech_id,)).fetchone() if tech_id else None
        conn.close()

        self.room_map = {r[1]: r[0] for r in self.rooms}
        self.emp_map = {e[1]: e[0] for e in self.emps}

        dialog_header(self, "Редактирование техники" if tech_id else "Новая единица техники",
                      "Заполните обязательные поля (*)")

        body = tk.Frame(self, bg=COLORS["card"], padx=16, pady=8)
        body.pack(fill="both", expand=True)

        self.v = {}
        self.v['ИнвентарныйНомер'] = tk.StringVar(value=row['ИнвентарныйНомер'] if row else "")
        self.v['Наименование'] = tk.StringVar(value=row['Наименование'] if row else "")
        self.v['Модель'] = tk.StringVar(value=(row['Модель'] or "") if row else "")
        self.v['СерийныйНомер'] = tk.StringVar(value=(row['СерийныйНомер'] or "") if row else "")
        self.v['ДатаПоступления'] = tk.StringVar(value=(row['ДатаПоступления'] or "") if row else "")
        self.v['ГарантияДо'] = tk.StringVar(value=(row['ГарантияДо'] or "") if row else "")
        self.v['Стоимость'] = tk.StringVar(value=str(row['Стоимость']) if row and row['Стоимость'] else "")
        self.v['Состояние'] = tk.StringVar(value=row['Состояние'] if row else "В работе")

        cur_room = next((d for d, c in self.room_map.items() if row and c == row['КодАудитории']), "")
        cur_emp = next((d for d, c in self.emp_map.items() if row and c == row['КодСотрудника']), "")
        self.v['Аудитория'] = tk.StringVar(value=cur_room)
        self.v['Сотрудник'] = tk.StringVar(value=cur_emp)
        self.v['Примечание'] = tk.StringVar(value=(row['Примечание'] or "") if row else "")

        field_row(body, "Инвентарный номер *", self.v['ИнвентарныйНомер'])
        field_row(body, "Наименование *", self.v['Наименование'])
        field_row(body, "Модель", self.v['Модель'])
        field_row(body, "Серийный номер", self.v['СерийныйНомер'])
        field_row(body, "Дата поступления", self.v['ДатаПоступления'])
        field_row(body, "Гарантия до", self.v['ГарантияДо'])
        field_row(body, "Стоимость, ₽", self.v['Стоимость'])
        field_row(body, "Состояние", self.v['Состояние'], "combo",
                  ["В работе", "На складе", "В ремонте", "Списано"])
        field_row(body, "Аудитория", self.v['Аудитория'], "combo", list(self.room_map.keys()))
        field_row(body, "Ответственный", self.v['Сотрудник'], "combo", list(self.emp_map.keys()))
        field_row(body, "Примечание", self.v['Примечание'])

        dialog_buttons(self, self.save, self.destroy)
        self.grab_set()

    def save(self):
        if not self.v['ИнвентарныйНомер'].get().strip() or not self.v['Наименование'].get().strip():
            messagebox.showerror("Ошибка", "Заполните обязательные поля (*)"); return
        try:
            cost = float(self.v['Стоимость'].get()) if self.v['Стоимость'].get().strip() else None
        except ValueError:
            messagebox.showerror("Ошибка", "Стоимость должна быть числом"); return

        data = (self.v['ИнвентарныйНомер'].get().strip(),
                self.v['Наименование'].get().strip(),
                self.v['Модель'].get().strip() or None,
                self.v['СерийныйНомер'].get().strip() or None,
                self.v['ДатаПоступления'].get().strip() or None,
                self.v['ГарантияДо'].get().strip() or None,
                cost, self.v['Состояние'].get(),
                self.room_map.get(self.v['Аудитория'].get()),
                self.emp_map.get(self.v['Сотрудник'].get()),
                self.v['Примечание'].get().strip() or None)
        conn = connect()
        try:
            if self.tech_id:
                conn.execute("""UPDATE Техника SET ИнвентарныйНомер=?,Наименование=?,Модель=?,
                                СерийныйНомер=?,ДатаПоступления=?,ГарантияДо=?,Стоимость=?,
                                Состояние=?,КодАудитории=?,КодСотрудника=?,Примечание=?
                                WHERE КодТехники=?""", data + (self.tech_id,))
            else:
                conn.execute("""INSERT INTO Техника (ИнвентарныйНомер,Наименование,Модель,
                                СерийныйНомер,ДатаПоступления,ГарантияДо,Стоимость,
                                Состояние,КодАудитории,КодСотрудника,Примечание)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", data)
            conn.commit()
        except sqlite3.IntegrityError as e:
            messagebox.showerror("Ошибка", f"Нарушена уникальность: {e}"); return
        finally:
            conn.close()
        self.on_save(); self.destroy()


# ==================== ДИАЛОГ: ПЕРЕМЕЩЕНИЕ ====================
class MoveDialog(tk.Toplevel):
    def __init__(self, parent, on_save):
        super().__init__(parent)
        self.title("Перемещение")
        self.geometry("540x440")
        self.configure(bg=COLORS["card"])
        self.on_save = on_save

        conn = connect()
        self.techs = conn.execute(
            "SELECT КодТехники, ИнвентарныйНомер||' — '||Наименование FROM Техника ORDER BY ИнвентарныйНомер").fetchall()
        self.tech_room = {t[0]: t[1] for t in conn.execute(
            "SELECT КодТехники, КодАудитории FROM Техника").fetchall()}
        self.rooms = conn.execute(
            "SELECT КодАудитории, НомерАудитории||COALESCE(' ('||Корпус||')','') FROM Аудитории ORDER BY НомерАудитории").fetchall()
        self.emps = conn.execute(
            "SELECT КодСотрудника, Фамилия||' '||Имя FROM Сотрудники ORDER BY Фамилия").fetchall()
        conn.close()

        self.tech_map = {t[1]: t[0] for t in self.techs}
        self.room_map = {r[1]: r[0] for r in self.rooms}
        self.emp_map = {e[1]: e[0] for e in self.emps}

        dialog_header(self, "Регистрация перемещения",
                      "Выберите технику и новое местоположение")

        body = tk.Frame(self, bg=COLORS["card"], padx=16, pady=8)
        body.pack(fill="both", expand=True)

        self.v = {}
        self.v['Техника'] = tk.StringVar()
        self.v['Откуда'] = tk.StringVar()
        self.v['Куда'] = tk.StringVar()
        self.v['Дата'] = tk.StringVar(value=date.today().isoformat())
        self.v['Сотрудник'] = tk.StringVar()
        self.v['Основание'] = tk.StringVar()

        field_row(body, "Техника *", self.v['Техника'], "combo", list(self.tech_map.keys()))
        field_row(body, "Откуда", self.v['Откуда'], "combo", [""] + list(self.room_map.keys()))
        field_row(body, "Куда *", self.v['Куда'], "combo", list(self.room_map.keys()))
        field_row(body, "Дата", self.v['Дата'])
        field_row(body, "Кто переместил", self.v['Сотрудник'], "combo", [""] + list(self.emp_map.keys()))
        field_row(body, "Основание", self.v['Основание'])

        dialog_buttons(self, self.save, self.destroy)
        self.grab_set()

    def save(self):
        if not self.v['Техника'].get() or not self.v['Куда'].get():
            messagebox.showerror("Ошибка", "Выберите технику и аудиторию «Куда»"); return
        tech_id = self.tech_map[self.v['Техника'].get()]
        room_from = self.room_map.get(self.v['Откуда'].get()) or self.tech_room.get(tech_id)
        room_to = self.room_map[self.v['Куда'].get()]
        emp_id = self.emp_map.get(self.v['Сотрудник'].get())
        conn = connect()
        try:
            conn.execute("""INSERT INTO Перемещения
                (КодТехники,КодАудиторииОткуда,КодАудиторииКуда,ДатаПеремещения,КодСотрудника,Основание)
                VALUES (?,?,?,?,?,?)""",
                (tech_id, room_from, room_to, self.v['Дата'].get(),
                 emp_id, self.v['Основание'].get().strip() or None))
            conn.execute("UPDATE Техника SET КодАудитории=? WHERE КодТехники=?", (room_to, tech_id))
            conn.commit()
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", str(e)); return
        finally:
            conn.close()
        self.on_save(); self.destroy()


# ==================== ДИАЛОГ: РЕМОНТ ====================
class RepairDialog(tk.Toplevel):
    def __init__(self, parent, repair_id, on_save):
        super().__init__(parent)
        self.title("Ремонт")
        self.geometry("540x460")
        self.configure(bg=COLORS["card"])
        self.repair_id, self.on_save = repair_id, on_save

        conn = connect()
        self.techs = conn.execute(
            "SELECT КодТехники, ИнвентарныйНомер||' — '||Наименование FROM Техника ORDER BY ИнвентарныйНомер").fetchall()
        row = conn.execute("SELECT * FROM Ремонты WHERE КодРемонта=?", (repair_id,)).fetchone() if repair_id else None
        conn.close()

        self.tech_map = {t[1]: t[0] for t in self.techs}
        cur = next((d for d, c in self.tech_map.items() if row and c == row['КодТехники']), "")

        dialog_header(self, "Ремонт техники", "Зафиксируйте неисправность и статус")

        body = tk.Frame(self, bg=COLORS["card"], padx=16, pady=8)
        body.pack(fill="both", expand=True)

        self.v = {}
        self.v['Техника'] = tk.StringVar(value=cur)
        self.v['ДатаНачала'] = tk.StringVar(value=(row['ДатаНачала'] or "") if row else "")
        self.v['ДатаОкончания'] = tk.StringVar(value=(row['ДатаОкончания'] or "") if row else "")
        self.v['Описание'] = tk.StringVar(value=(row['ОписаниеНеисправности'] or "") if row else "")
        self.v['Стоимость'] = tk.StringVar(value=str(row['СтоимостьРемонта']) if row and row['СтоимостьРемонта'] else "")
        self.v['Статус'] = tk.StringVar(value=row['Статус'] if row else "В процессе")

        field_row(body, "Техника *", self.v['Техника'], "combo", list(self.tech_map.keys()))
        field_row(body, "Дата начала", self.v['ДатаНачала'])
        field_row(body, "Дата окончания", self.v['ДатаОкончания'])
        field_row(body, "Неисправность", self.v['Описание'])
        field_row(body, "Стоимость, ₽", self.v['Стоимость'])
        field_row(body, "Статус", self.v['Статус'], "combo", ["В процессе", "Завершен"])

        dialog_buttons(self, self.save, self.destroy)
        self.grab_set()

    def save(self):
        if not self.v['Техника'].get():
            messagebox.showerror("Ошибка", "Выберите технику"); return
        tech_id = self.tech_map[self.v['Техника'].get()]
        try:
            cost = float(self.v['Стоимость'].get()) if self.v['Стоимость'].get().strip() else None
        except ValueError:
            messagebox.showerror("Ошибка", "Стоимость — число"); return
        data = (tech_id, self.v['ДатаНачала'].get().strip() or None,
                self.v['ДатаОкончания'].get().strip() or None,
                self.v['Описание'].get().strip() or None, cost, self.v['Статус'].get())
        conn = connect()
        try:
            if self.repair_id:
                conn.execute("""UPDATE Ремонты SET КодТехники=?,ДатаНачала=?,ДатаОкончания=?,
                                ОписаниеНеисправности=?,СтоимостьРемонта=?,Статус=?
                                WHERE КодРемонта=?""", data + (self.repair_id,))
            else:
                conn.execute("""INSERT INTO Ремонты (КодТехники,ДатаНачала,ДатаОкончания,
                                ОписаниеНеисправности,СтоимостьРемонта,Статус)
                                VALUES (?,?,?,?,?,?)""", data)
            new_state = "В ремонте" if self.v['Статус'].get() == "В процессе" else "В работе"
            conn.execute("UPDATE Техника SET Состояние=? WHERE КодТехники=?", (new_state, tech_id))
            conn.commit()
        finally:
            conn.close()
        self.on_save(); self.destroy()


# ==================== ДИАЛОГИ СПРАВОЧНИКОВ ====================
class RoomDialog(tk.Toplevel):
    def __init__(self, parent, room_id, on_save):
        super().__init__(parent)
        self.title("Аудитория"); self.geometry("440x340")
        self.configure(bg=COLORS["card"])
        self.room_id, self.on_save = room_id, on_save
        row = None
        if room_id:
            c = connect()
            row = c.execute("SELECT * FROM Аудитории WHERE КодАудитории=?", (room_id,)).fetchone()
            c.close()
        dialog_header(self, "Аудитория")
        body = tk.Frame(self, bg=COLORS["card"], padx=16, pady=8)
        body.pack(fill="both", expand=True)
        self.v = {
            'НомерАудитории': tk.StringVar(value=row['НомерАудитории'] if row else ""),
            'Корпус': tk.StringVar(value=(row['Корпус'] or "") if row else ""),
            'Этаж': tk.StringVar(value=str(row['Этаж']) if row and row['Этаж'] else ""),
            'Примечание': tk.StringVar(value=(row['Примечание'] or "") if row else ""),
        }
        field_row(body, "Номер *", self.v['НомерАудитории'])
        field_row(body, "Корпус", self.v['Корпус'])
        field_row(body, "Этаж", self.v['Этаж'])
        field_row(body, "Примечание", self.v['Примечание'])
        dialog_buttons(self, self.save, self.destroy)
        self.grab_set()

    def save(self):
        if not self.v['НомерАудитории'].get().strip():
            messagebox.showerror("Ошибка", "Введите номер"); return
        data = (self.v['НомерАудитории'].get().strip(),
                self.v['Корпус'].get().strip() or None,
                int(self.v['Этаж'].get()) if self.v['Этаж'].get().strip().isdigit() else None,
                self.v['Примечание'].get().strip() or None)
        c = connect()
        try:
            if self.room_id:
                c.execute("UPDATE Аудитории SET НомерАудитории=?,Корпус=?,Этаж=?,Примечание=? WHERE КодАудитории=?",
                          data + (self.room_id,))
            else:
                c.execute("INSERT INTO Аудитории (НомерАудитории,Корпус,Этаж,Примечание) VALUES (?,?,?,?)", data)
            c.commit()
        except sqlite3.IntegrityError as e:
            messagebox.showerror("Ошибка", f"Такой номер уже есть: {e}"); return
        finally:
            c.close()
        self.on_save(); self.destroy()


class EmpDialog(tk.Toplevel):
    def __init__(self, parent, emp_id, on_save):
        super().__init__(parent)
        self.title("Сотрудник"); self.geometry("440x400")
        self.configure(bg=COLORS["card"])
        self.emp_id, self.on_save = emp_id, on_save
        row = None
        if emp_id:
            c = connect()
            row = c.execute("SELECT * FROM Сотрудники WHERE КодСотрудника=?", (emp_id,)).fetchone()
            c.close()
        dialog_header(self, "Сотрудник")
        body = tk.Frame(self, bg=COLORS["card"], padx=16, pady=8)
        body.pack(fill="both", expand=True)
        self.v = {
            'Фамилия': tk.StringVar(value=row['Фамилия'] if row else ""),
            'Имя': tk.StringVar(value=row['Имя'] if row else ""),
            'Отчество': tk.StringVar(value=(row['Отчество'] or "") if row else ""),
            'Должность': tk.StringVar(value=(row['Должность'] or "") if row else ""),
            'Телефон': tk.StringVar(value=(row['Телефон'] or "") if row else ""),
        }
        field_row(body, "Фамилия *", self.v['Фамилия'])
        field_row(body, "Имя *", self.v['Имя'])
        field_row(body, "Отчество", self.v['Отчество'])
        field_row(body, "Должность", self.v['Должность'])
        field_row(body, "Телефон", self.v['Телефон'])
        dialog_buttons(self, self.save, self.destroy)
        self.grab_set()

    def save(self):
        if not self.v['Фамилия'].get().strip() or not self.v['Имя'].get().strip():
            messagebox.showerror("Ошибка", "Фамилия и имя обязательны"); return
        data = (self.v['Фамилия'].get().strip(), self.v['Имя'].get().strip(),
                self.v['Отчество'].get().strip() or None,
                self.v['Должность'].get().strip() or None,
                self.v['Телефон'].get().strip() or None)
        c = connect()
        if self.emp_id:
            c.execute("UPDATE Сотрудники SET Фамилия=?,Имя=?,Отчество=?,Должность=?,Телефон=? WHERE КодСотрудника=?",
                      data + (self.emp_id,))
        else:
            c.execute("INSERT INTO Сотрудники (Фамилия,Имя,Отчество,Должность,Телефон) VALUES (?,?,?,?,?)", data)
        c.commit(); c.close()
        self.on_save(); self.destroy()


# ==================== БАЗОВАЯ ВКЛАДКА ====================
class BaseTab(ttk.Frame):
    columns = ()
    headers = ()
    dialog_class = None
    delete_sql = ""
    search_placeholder = "Поиск…"

    def __init__(self, parent):
        super().__init__(parent, padding=12)
        self.build()

    def build(self):
        # Панель инструментов
        bar = ttk.Frame(self); bar.pack(fill="x", pady=(0, 10))
        ttk.Button(bar, text="➕ Добавить", style="Success.TButton",
                   command=self.add).pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="✏️ Изменить", style="Primary.TButton",
                   command=self.edit).pack(side="left", padx=6)
        ttk.Button(bar, text="🗑 Удалить", style="Danger.TButton",
                   command=self.delete).pack(side="left", padx=6)
        ttk.Button(bar, text="🔄 Обновить", command=self.refresh).pack(side="left", padx=6)

        search_box = ttk.Frame(bar); search_box.pack(side="right")
        ttk.Label(search_box, text="🔎", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *_: self.refresh())
        ttk.Entry(search_box, textvariable=self.search, width=28).pack(side="left")

        # Таблица в карточке
        wrap, inner = card(self)
        wrap.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(inner, columns=self.columns, show="headings")
        for c, h in zip(self.columns, self.headers or self.columns):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=140, anchor="w")
        sb = ttk.Scrollbar(inner, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("odd", background=COLORS["stripe"])
        self.refresh()

    def _fill(self, rows):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            self.tree.insert("", "end",
                             values=[str(x) if x is not None else "" for x in r],
                             tags=("odd",) if i % 2 else ())

    def refresh(self): raise NotImplementedError
    def add(self): self.dialog_class(self, None, self.refresh)

    def edit(self):
        sel = self.tree.selection()
        if not sel: return
        self.dialog_class(self, int(self.tree.item(sel[0])["values"][0]), self.refresh)

    def delete(self):
        sel = self.tree.selection()
        if not sel: return
        if not messagebox.askyesno("Удаление", "Удалить выбранную запись?"): return
        id_ = int(self.tree.item(sel[0])["values"][0])
        c = connect()
        try:
            c.execute(self.delete_sql, (id_,)); c.commit()
        except sqlite3.IntegrityError as e:
            messagebox.showerror("Ошибка", f"Есть связанные записи: {e}")
        finally:
            c.close()
        self.refresh()


class TechTab(BaseTab):
    columns = ("ID", "Инв.№", "Наименование", "Модель", "Состояние", "Аудитория", "Ответственный")
    headers = ("ID", "Инв. №", "Наименование", "Модель", "Состояние", "Аудитория", "Ответственный")
    dialog_class = TechDialog
    delete_sql = "DELETE FROM Техника WHERE КодТехники=?"

    def refresh(self):
        q = self.search.get().strip()
        c = connect()
        rows = c.execute("""
            SELECT Т.КодТехники, Т.ИнвентарныйНомер, Т.Наименование, Т.Модель, Т.Состояние,
                   COALESCE(А.НомерАудитории,''), COALESCE(С.Фамилия||' '||С.Имя,'')
            FROM Техника Т
            LEFT JOIN Аудитории А ON Т.КодАудитории=А.КодАудитории
            LEFT JOIN Сотрудники С ON Т.КодСотрудника=С.КодСотрудника
            WHERE ?='' OR Т.ИнвентарныйНомер LIKE ? OR Т.Наименование LIKE ? OR Т.Модель LIKE ?
            ORDER BY Т.ИнвентарныйНомер""",
            (q, f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
        c.close()
        self._fill(rows)


class MoveTab(BaseTab):
    columns = ("ID", "Техника", "Откуда", "Куда", "Дата", "Кто", "Основание")
    headers = ("ID", "Техника", "Откуда", "Куда", "Дата", "Кто", "Основание")
    delete_sql = "DELETE FROM Перемещения WHERE КодПеремещения=?"

    def add(self): MoveDialog(self, self.refresh)
    def edit(self): messagebox.showinfo("Информация", "Перемещения не редактируются — удалите и создайте новое.")

    def refresh(self):
        c = connect()
        rows = c.execute("""
            SELECT П.КодПеремещения, Т.ИнвентарныйНомер||' — '||Т.Наименование,
                   COALESCE(A1.НомерАудитории,''), COALESCE(A2.НомерАудитории,''),
                   COALESCE(П.ДатаПеремещения,''), COALESCE(С.Фамилия||' '||С.Имя,''),
                   COALESCE(П.Основание,'')
            FROM Перемещения П
            INNER JOIN Техника Т ON П.КодТехники=Т.КодТехники
            LEFT JOIN Аудитории A1 ON П.КодАудиторииОткуда=A1.КодАудитории
            LEFT JOIN Аудитории A2 ON П.КодАудиторииКуда=A2.КодАудитории
            LEFT JOIN Сотрудники С ON П.КодСотрудника=С.КодСотрудника
            ORDER BY П.ДатаПеремещения DESC""").fetchall()
        c.close()
        self._fill(rows)


class RepairTab(BaseTab):
    columns = ("ID", "Техника", "Начало", "Окончание", "Неисправность", "Стоимость", "Статус")
    headers = ("ID", "Техника", "Начало", "Окончание", "Неисправность", "Стоимость", "Статус")
    dialog_class = RepairDialog
    delete_sql = "DELETE FROM Ремонты WHERE КодРемонта=?"

    def refresh(self):
        c = connect()
        rows = c.execute("""
            SELECT Р.КодРемонта, Т.ИнвентарныйНомер||' — '||Т.Наименование,
                   COALESCE(Р.ДатаНачала,''), COALESCE(Р.ДатаОкончания,''),
                   COALESCE(Р.ОписаниеНеисправности,''), COALESCE(Р.СтоимостьРемонта,''),
                   COALESCE(Р.Статус,'')
            FROM Ремонты Р INNER JOIN Техника Т ON Р.КодТехники=Т.КодТехники
            ORDER BY Р.ДатаНачала DESC""").fetchall()
        c.close()
        self._fill(rows)


class RoomTab(BaseTab):
    columns = ("ID", "Номер", "Корпус", "Этаж", "Примечание")
    headers = ("ID", "Номер", "Корпус", "Этаж", "Примечание")
    dialog_class = RoomDialog
    delete_sql = "DELETE FROM Аудитории WHERE КодАудитории=?"

    def refresh(self):
        c = connect()
        rows = [(r[0], r[1] or "", r[2] or "", r[3] or "", r[4] or "")
                for r in c.execute("SELECT * FROM Аудитории ORDER BY НомерАудитории").fetchall()]
        c.close()
        self._fill(rows)


class EmpTab(BaseTab):
    columns = ("ID", "Фамилия", "Имя", "Отчество", "Должность", "Телефон")
    headers = ("ID", "Фамилия", "Имя", "Отчество", "Должность", "Телефон")
    dialog_class = EmpDialog
    delete_sql = "DELETE FROM Сотрудники WHERE КодСотрудника=?"

    def refresh(self):
        c = connect()
        rows = [(r[0], r[1] or "", r[2] or "", r[3] or "", r[4] or "", r[5] or "")
                for r in c.execute("SELECT * FROM Сотрудники ORDER BY Фамилия").fetchall()]
        c.close()
        self._fill(rows)


# ==================== ОТЧЕТЫ ====================
class ReportTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=16)
        head = ttk.Frame(self); head.pack(fill="x", pady=(0, 14))
        ttk.Label(head, text="Отчеты и выборки", style="H1.TLabel").pack(side="left")
        ttk.Label(head, text="Выберите нужный отчет", style="Muted.TLabel").pack(side="left", padx=10)

        grid = ttk.Frame(self); grid.pack(fill="both", expand=True)
        reports = [
            ("🏢", "Техника по аудиториям", "Полный список с местоположением и ответственным", self.r_rooms),
            ("🔧", "Техника в ремонте", "Все единицы с активным ремонтом", self.r_repair),
            ("🔀", "История перемещений", "Кто, когда и куда перемещал технику", self.r_moves),
            ("⏰", "Истекающая гарантия", "Техника с гарантией менее 30 дней", self.r_warranty),
            ("💾", "Резервная копия ИС", "Создание полной резервной копии БД, SQL-дампа и ZIP-архива", self.r_backup),
            ("🛡", "Обслуживание БД", "Проверка целостности PRAGMA, дефрагментация VACUUM и ANALYZE", self.r_maintain),
        ]
        for i, (icon, title, desc, fn) in enumerate(reports):
            r, col = divmod(i, 2)
            wrap, inner = card(grid)
            wrap.grid(row=r, column=col, padx=6, pady=6, sticky="nsew")
            grid.columnconfigure(col, weight=1)
            tk.Label(inner, text=icon, font=("Segoe UI", 28),
                     bg=COLORS["card"]).pack(anchor="w")
            tk.Label(inner, text=title, font=FONT_H1, bg=COLORS["card"],
                     fg=COLORS["text"]).pack(anchor="w", pady=(4, 2))
            tk.Label(inner, text=desc, font=FONT, bg=COLORS["card"],
                     fg=COLORS["muted"], wraplength=280, justify="left").pack(anchor="w", pady=(0, 10))
            ttk.Button(inner, text="Открыть  →", style="Primary.TButton",
                       command=fn).pack(anchor="w")

    def show(self, title, sql, headers):
        c = connect(); rows = c.execute(sql).fetchall(); c.close()
        win = tk.Toplevel(self); win.title(title); win.geometry("1000x560")
        win.configure(bg=COLORS["card"])
        dialog_header(win, title, f"Всего записей: {len(rows)}")
        wrap, inner = card(win); wrap.pack(fill="both", expand=True, padx=12, pady=12)
        tree = ttk.Treeview(inner, columns=headers, show="headings")
        for h in headers:
            tree.heading(h, text=h); tree.column(h, width=140, anchor="w")
        for i, r in enumerate(rows):
            tree.insert("", "end",
                        values=[str(x) if x is not None else "" for x in r],
                        tags=("odd",) if i % 2 else ())
        tree.tag_configure("odd", background=COLORS["stripe"])
        sb = ttk.Scrollbar(inner, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    def r_rooms(self):
        self.show("Техника по аудиториям", """
            SELECT Т.ИнвентарныйНомер, Т.Наименование, Т.Модель, Т.Состояние,
                   COALESCE(А.НомерАудитории,'—'), COALESCE(С.Фамилия||' '||С.Имя,'—')
            FROM Техника Т
            LEFT JOIN Аудитории А ON Т.КодАудитории=А.КодАудитории
            LEFT JOIN Сотрудники С ON Т.КодСотрудника=С.КодСотрудника
            ORDER BY А.НомерАудитории, Т.ИнвентарныйНомер""",
            ["Инв.№", "Наименование", "Модель", "Состояние", "Аудитория", "Ответственный"])

    def r_repair(self):
        self.show("Техника в ремонте", """
            SELECT Т.ИнвентарныйНомер, Т.Наименование, Т.Модель,
                   COALESCE(Р.ДатаНачала,''), COALESCE(Р.ОписаниеНеисправности,''),
                   COALESCE(Р.СтоимостьРемонта,'')
            FROM Техника Т INNER JOIN Ремонты Р ON Т.КодТехники=Р.КодТехники
            WHERE Р.Статус='В процессе' OR Т.Состояние='В ремонте'""",
            ["Инв.№", "Наименование", "Модель", "Начало", "Неисправность", "Стоимость"])

    def r_moves(self):
        self.show("История перемещений", """
            SELECT Т.ИнвентарныйНомер, Т.Наименование, COALESCE(П.ДатаПеремещения,''),
                   COALESCE(A1.НомерАудитории,'—'), COALESCE(A2.НомерАудитории,'—'),
                   COALESCE(С.Фамилия||' '||С.Имя,'—')
            FROM Перемещения П
            INNER JOIN Техника Т ON П.КодТехники=Т.КодТехники
            LEFT JOIN Аудитории A1 ON П.КодАудиторииОткуда=A1.КодАудитории
            LEFT JOIN Аудитории A2 ON П.КодАудиторииКуда=A2.КодАудитории
            LEFT JOIN Сотрудники С ON П.КодСотрудника=С.КодСотрудника
            ORDER BY П.ДатаПеремещения DESC""",
            ["Инв.№", "Наименование", "Дата", "Откуда", "Куда", "Кто"])

    def r_warranty(self):
        self.show("Истекающая гарантия (30 дней)", """
            SELECT ИнвентарныйНомер, Наименование, Модель, ГарантияДо
            FROM Техника
            WHERE ГарантияДо IS NOT NULL AND ГарантияДо<>''
              AND date(ГарантияДо) BETWEEN date('now') AND date('now','+30 days')
            ORDER BY ГарантияДо""",
            ["Инв.№", "Наименование", "Модель", "Гарантия до"])


    def r_backup(self):
        info = create_backup()
        messagebox.showinfo(
            "Резервная копия создана",
            f"Архив: {info['zip_archive']}\n"
            f"Размер: {info['zip_size_bytes']} байт\n"
            f"SHA-256: {info['sha256'][:24]}..."
        )

    def r_maintain(self):
        res = perform_maintenance()
        counts_str = ", ".join(f"{k}: {v}" for k, v in res["table_counts"].items())
        messagebox.showinfo(
            "Обслуживание выполнено",
            f"Целостность БД (integrity_check): {res['integrity_check']}\n"
            f"Ошибок внешних ключей: {res['fk_violations']}\n"
            f"Оптимизация: VACUUM + ANALYZE выполнены\n"
            f"Записей в таблицах: {counts_str}"
        )




# ==================== РЕЗЕРВНОЕ КОПИРОВАНИЕ И ОБСЛУЖИВАНИЕ (ПМ.06) ====================
import os
import shutil
import zipfile
import hashlib
from datetime import datetime

BACKUP_DIR = "backups"


def create_backup(backup_dir=BACKUP_DIR):
    """Создает горячую резервную копию БД SQLite, SQL-дамп и ZIP-архив ИС."""
    os.makedirs(backup_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    db_backup_path = os.path.join(backup_dir, f"tech_accounting_{ts}.db")
    sql_dump_path = os.path.join(backup_dir, f"tech_accounting_{ts}_dump.sql")
    zip_path = os.path.join(backup_dir, f"backup_IS_tech_accounting_{ts}.zip")

    # 1. Горячее резервное копирование средствами SQLite Online Backup API
    src_conn = connect()
    dst_conn = sqlite3.connect(db_backup_path)
    with dst_conn:
        src_conn.backup(dst_conn)
    dst_conn.close()

    # 2. Выгрузка текстового SQL-дампа
    with open(sql_dump_path, "w", encoding="utf-8") as f:
        for line in src_conn.iterdump():
            f.write(f"{line}\n")
    src_conn.close()

    # 3. Упаковка БД, SQL-дампа и исходного кода в ZIP-архив
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(db_backup_path, os.path.basename(db_backup_path))
        zf.write(sql_dump_path, os.path.basename(sql_dump_path))
        if os.path.exists(__file__):
            zf.write(__file__, os.path.basename(__file__))

    # Вычисление контрольной суммы SHA-256
    sha256 = hashlib.sha256()
    with open(zip_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)

    return {
        "timestamp": ts,
        "db_backup": db_backup_path,
        "sql_dump": sql_dump_path,
        "zip_archive": zip_path,
        "zip_size_bytes": os.path.getsize(zip_path),
        "sha256": sha256.hexdigest(),
    }


def perform_maintenance():
    """Выполняет регламентное обслуживание БД: проверка целостности, внешних ключей, VACUUM и ANALYZE."""
    conn = connect()
    cur = conn.cursor()
    integrity = cur.execute("PRAGMA integrity_check").fetchone()[0]
    fk_violations = cur.execute("PRAGMA foreign_key_check").fetchall()
    counts = {}
    for tbl in ("Аудитории", "Сотрудники", "Техника", "Перемещения", "Ремонты"):
        counts[tbl] = cur.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
    conn.close()

    # Оптимизация и дефрагментация БД
    conn_opt = sqlite3.connect(DB_NAME)
    conn_opt.execute("VACUUM")
    conn_opt.execute("ANALYZE")
    conn_opt.close()

    return {
        "integrity_check": integrity,
        "fk_violations": len(fk_violations),
        "table_counts": counts,
        "db_size_bytes": os.path.getsize(DB_NAME) if os.path.exists(DB_NAME) else 0,
    }

# ==================== ГЛАВНОЕ ОКНО ====================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ИС учета техники в техникуме")
        self.geometry("1200x720")
        self.configure(bg=COLORS["bg"])
        apply_style(self)

        # Шапка
        header = tk.Frame(self, bg=COLORS["header"], height=72)
        header.pack(fill="x")
        header.pack_propagate(False)
        left = tk.Frame(header, bg=COLORS["header"]); left.pack(side="left", padx=20, pady=10)
        tk.Label(left, text="🖥  Учет техники", bg=COLORS["header"],
                 fg=COLORS["header_text"], font=("Segoe UI", 18, "bold")).pack(anchor="w")
        tk.Label(left, text="Информационная система техникума",
                 bg=COLORS["header"], fg="#94a3b8",
                 font=("Segoe UI", 10)).pack(anchor="w")
        right = tk.Frame(header, bg=COLORS["header"]); right.pack(side="right", padx=20)
        tk.Label(right, text=date.today().strftime("%d.%m.%Y"),
                 bg=COLORS["header"], fg="#cbd5e1",
                 font=("Segoe UI", 10)).pack()

        # Notebook
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=12, pady=12)
        nb.add(TechTab(nb), text="  Техника  ")
        nb.add(MoveTab(nb), text="  Перемещения  ")
        nb.add(RepairTab(nb), text="  Ремонты  ")
        nb.add(RoomTab(nb), text="  Аудитории  ")
        nb.add(EmpTab(nb), text="  Сотрудники  ")
        nb.add(ReportTab(nb), text="  Отчеты  ")

        # Статус-бар
        status = tk.Frame(self, bg=COLORS["header"], height=26)
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)
        tk.Label(status, text="  ● Система работает",
                 bg=COLORS["header"], fg="#4ade80",
                 font=("Segoe UI", 9)).pack(side="left", padx=12)
        tk.Label(status, text="ПМ.06 · Учебная практика · Шадрина А.Ю.  ",
                 bg=COLORS["header"], fg="#94a3b8",
                 font=("Segoe UI", 9)).pack(side="right")


if __name__ == "__main__":
    import sys
    init_db()
    if "--backup" in sys.argv:
        print("BACKUP_RESULT:", create_backup())
    elif "--maintain" in sys.argv:
        print("MAINTAIN_RESULT:", perform_maintenance())
    else:
        App().mainloop()
