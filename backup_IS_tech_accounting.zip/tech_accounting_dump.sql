BEGIN TRANSACTION;
ANALYZE "sqlite_master";
INSERT INTO "sqlite_stat1" VALUES('Ремонты',NULL,'1');
INSERT INTO "sqlite_stat1" VALUES('Перемещения',NULL,'1');
INSERT INTO "sqlite_stat1" VALUES('Техника','sqlite_autoindex_Техника_1','10 1');
INSERT INTO "sqlite_stat1" VALUES('Сотрудники',NULL,'3');
INSERT INTO "sqlite_stat1" VALUES('Аудитории','sqlite_autoindex_Аудитории_1','5 1');
CREATE TABLE Аудитории (
    КодАудитории INTEGER PRIMARY KEY AUTOINCREMENT,
    НомерАудитории TEXT NOT NULL UNIQUE,
    Корпус TEXT, Этаж INTEGER, Примечание TEXT);
INSERT INTO "Аудитории" VALUES(1,'101','Основной',1,'Кабинет информатики и ИКТ');
INSERT INTO "Аудитории" VALUES(2,'201','Основной',2,'Лаборатория информационных систем');
INSERT INTO "Аудитории" VALUES(3,'305','Лабораторный',3,'Лаборатория программирования и БД');
INSERT INTO "Аудитории" VALUES(4,'306','Лабораторный',3,'Кабинет сетевого администрирования');
INSERT INTO "Аудитории" VALUES(5,'Склад','—',1,'Помещение хранения резервного оборудования');
CREATE TABLE Перемещения (
    КодПеремещения INTEGER PRIMARY KEY AUTOINCREMENT,
    КодТехники INTEGER NOT NULL,
    КодАудиторииОткуда INTEGER, КодАудиторииКуда INTEGER,
    ДатаПеремещения TEXT, КодСотрудника INTEGER, Основание TEXT,
    FOREIGN KEY (КодТехники) REFERENCES Техника(КодТехники),
    FOREIGN KEY (КодАудиторииОткуда) REFERENCES Аудитории(КодАудитории),
    FOREIGN KEY (КодАудиторииКуда) REFERENCES Аудитории(КодАудитории),
    FOREIGN KEY (КодСотрудника) REFERENCES Сотрудники(КодСотрудника));
INSERT INTO "Перемещения" VALUES(1,7,1,5,'2026-10-20',1,'Плановая замена проектора в ауд. 101');
CREATE TABLE Ремонты (
    КодРемонта INTEGER PRIMARY KEY AUTOINCREMENT,
    КодТехники INTEGER NOT NULL,
    ДатаНачала TEXT, ДатаОкончания TEXT,
    ОписаниеНеисправности TEXT, СтоимостьРемонта REAL, Статус TEXT,
    FOREIGN KEY (КодТехники) REFERENCES Техника(КодТехники));
INSERT INTO "Ремонты" VALUES(1,4,'2026-10-27',NULL,'Не включается (неисправность цепи питания)',3500.0,'В процессе');
CREATE TABLE Сотрудники (
    КодСотрудника INTEGER PRIMARY KEY AUTOINCREMENT,
    Фамилия TEXT NOT NULL, Имя TEXT NOT NULL, Отчество TEXT,
    Должность TEXT, Телефон TEXT);
INSERT INTO "Сотрудники" VALUES(1,'Иванов','Пётр','Сергеевич','Заведующий лабораторией','+7 (900) 111-22-33');
INSERT INTO "Сотрудники" VALUES(2,'Петрова','Анна','Викторовна','Преподаватель','+7 (900) 222-33-44');
INSERT INTO "Сотрудники" VALUES(3,'Сидоров','Максим','Олегович','Системный администратор','+7 (900) 333-44-55');
CREATE TABLE Техника (
    КодТехники INTEGER PRIMARY KEY AUTOINCREMENT,
    ИнвентарныйНомер TEXT NOT NULL UNIQUE,
    Наименование TEXT NOT NULL, Модель TEXT, СерийныйНомер TEXT,
    ДатаПоступления TEXT, ГарантияДо TEXT, Стоимость REAL,
    Состояние TEXT, КодАудитории INTEGER, КодСотрудника INTEGER,
    Примечание TEXT,
    FOREIGN KEY (КодАудитории) REFERENCES Аудитории(КодАудитории),
    FOREIGN KEY (КодСотрудника) REFERENCES Сотрудники(КодСотрудника));
INSERT INTO "Техника" VALUES(1,'ИНВ-001','Компьютер','HP ProDesk 400 G7','CZC1048A01','2024-09-01','2027-09-01',64500.0,'В работе',2,1,'Рабочее место №1');
INSERT INTO "Техника" VALUES(2,'ИНВ-002','Компьютер','HP ProDesk 400 G7','CZC1048A02','2024-09-01','2027-09-01',64500.0,'В работе',2,1,'Рабочее место №2');
INSERT INTO "Техника" VALUES(3,'ИНВ-003','Проектор','Epson EB-X41','X41992014','2023-11-15','2026-11-15',48900.0,'В работе',2,2,'Потолочный подвес');
INSERT INTO "Техника" VALUES(4,'ИНВ-004','Принтер','Canon i-SENSYS','CNB882109','2023-05-20','2026-05-20',29400.0,'В ремонте',3,3,'Требует замены блока питания');
INSERT INTO "Техника" VALUES(5,'ИНВ-005','Компьютер','Lenovo ThinkCentre','LNV550192','2024-02-10','2027-02-10',68000.0,'В работе',3,3,'Сервер БД учебной лаборатории');
INSERT INTO "Техника" VALUES(6,'ИНВ-006','Интерактивная доска','Smart Board MX','SMB774120','2024-08-25','2027-08-25',145000.0,'В работе',3,2,'В комплекте со стилусами');
INSERT INTO "Техника" VALUES(7,'ИНВ-007','Проектор','BenQ MS527','BNQ331098','2022-10-10','2025-10-10',36500.0,'На складе',5,1,'Резервный фонд');
INSERT INTO "Техника" VALUES(8,'ИНВ-008','Принтер','HP LaserJet P1102','VNC441023','2023-11-10','2026-11-10',24800.0,'В работе',1,2,'Сетевая печать');
INSERT INTO "Техника" VALUES(9,'ИНВ-009','Ноутбук','Asus VivoBook 15','ASN992011','2025-01-15','2027-01-15',58900.0,'В работе',4,3,'Мобильный стенд диагностики');
INSERT INTO "Техника" VALUES(10,'ИНВ-010','Компьютер','Aquarius Pro P30','AQR110294','2019-09-01','2022-09-01',42000.0,'Списано',5,1,'Акт списания №14 от 10.09.2026');
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('Аудитории',5);
INSERT INTO "sqlite_sequence" VALUES('Сотрудники',3);
INSERT INTO "sqlite_sequence" VALUES('Техника',10);
INSERT INTO "sqlite_sequence" VALUES('Перемещения',1);
INSERT INTO "sqlite_sequence" VALUES('Ремонты',1);
COMMIT;
